import subprocess
import platform
from jetpack import util
import os
import json
import Queue
import threading
from jetpack.converge.userdata import Userdata
from jetpack import amqp


class ConvergeError(Exception):
    pass


def _solo_mode(bootstrap_path):
    """ Check if the instance is running chef-solo or chef-client """
    with open("%s/user-data.json" % bootstrap_path) as f:
        userdata = json.loads(f.read())

    # In my.cyclecloud.com we used to pass https://null but that is now
    # unsupported, we only have to check to see if chefServer is defined
    # to determine if we're in solo mode or not.
    chef_server = userdata['user_data']['config']['chefServer']
    if chef_server is None or chef_server == "":
        return True
    else:
        return False


def _cache_userdata(bootstrap_path):
    cached_file = os.path.join(bootstrap_path, "user-data.json")
    if os.path.exists(cached_file) and os.path.getsize(cached_file) > 0:
        return

    ud = Userdata()
    json_data = ud.to_json()
    with open(cached_file, 'w') as f:
        f.write(str(json_data))


def _generate_chef_config(is_linux, solo, bootstrap_path, log_path):
    solo_flag = ""
    if solo:
        solo_flag = "--solo"
    try:
        if is_linux:
            subprocess.check_call('%s/generate_chef_config.rb %s >> %s/generate_chef_config.log 2>&1' % (bootstrap_path, solo_flag, log_path), shell=True)
        else:
            subprocess.check_call('ruby %s\\generate_chef_config.rb %s >> %s\\generate_chef_config.log 2>&1' % (bootstrap_path, solo_flag, log_path), shell=True)
    except:
        raise ConvergeError("A problem occurred generating Chef configuration")


def _sync_chef_repos(is_linux, bootstrap_path, log_path):
    try:
        if is_linux:
            subprocess.check_call('%s/sync_chef_repos.py >> %s/sync_chef_repos.log 2>&1' % (bootstrap_path, log_path), shell=True)
        else:
            subprocess.check_call('python %s\\sync_chef_repos.py >> %s\\sync_chef_repos.log 2>&1' % (bootstrap_path, log_path), shell=True)
    except:
        raise ConvergeError("A problem occurred syncing Chef repos to disk")


def _run_chef_solo(is_linux, log_path, flags):
    try:
        if is_linux:
            subprocess.check_call('chef-solo -c /opt/cycle/jetpack/system/chef/solo.rb -L %s/chef-client.log %s' % (log_path, flags), shell=True)
        else:
            subprocess.check_call('chef-solo.bat -c C:\\cycle\\jetpack\\system\\chef\\solo.rb -L %s\\chef-client.log %s' % (log_path, flags), shell=True)
    except:
        raise ConvergeError("A problem occurred while running Chef, check chef-client.log for details")


def _run_chef_client(is_linux, log_path, flags):
    try:
        if is_linux:
            subprocess.check_call('chef-client -c /opt/cycle/jetpack/system/chef/client.rb -L %s/chef-client.log %s' % (log_path, flags), shell=True)
        else:
            subprocess.check_call('chef-client.bat -c C:\\cycle\\jetpack\\system\\chef\\client.rb -L %s\\chef-client.log %s' % (log_path, flags), shell=True)
    except:
        raise ConvergeError("A problem occurred while running Chef, check chef-client.log for details")


def _send_installation_status(config, status):
    message = {"installation_status": status}

    try:
        amqp.send(message=json.dumps(message), routing_key="cyclecloud.installation", config=config)
    except Exception, e:
        raise e


def _status_loop(config, status_queue):
    while True:
        status = status_queue.get()
        _send_installation_status(config, status)
        if status in ["success", "failure"]:
            return


def execute(debug=False, no_sync=False):
    """ Shells out to the converge script that is already on the box """

    is_linux = True
    if platform.system().lower().startswith('win'):
        is_linux = False
        bootstrap_path = 'c:\\cycle\\jetpack\\system\\bootstrap'
        log_path = 'c:\\cycle\\jetpack\\logs'
        pid_file = 'c:\\cycle\\jetpack\\system\\run\\converge.pid'
    else:
        bootstrap_path = "/opt/cycle/jetpack/system/bootstrap"
        log_path = '/opt/cycle/jetpack/logs'
        pid_file = '/opt/cycle/jetpack/system/run/converge.pid'

    # This should only run once at a time
    if util.already_running(pid_file):
        raise ConvergeError("Converge process already running...")

    # NOTE: This is done with multiple if linux else windows checks because the
    # subprocess calls will be replaced with OS independant python code in the future

    ######################
    # 1 - Cache userdata #
    ######################
    _cache_userdata(bootstrap_path)

    ################################################
    # 2 - Determine if we're running in solo mode #
    ################################################
    solo = _solo_mode(bootstrap_path)

    #############################
    # 3 - Configure jetpack CLI #
    #############################
    from jetpack.admin import configure
    try:
        config = configure.execute()
    except configure.JetpackConfigureError:
        raise ConvergeError("Unable to configure jetpack!")

    #################################
    # 4 - Send booted status signal #
    #################################
    status_queue = Queue.Queue()
    status_thread = threading.Thread(target=_status_loop, args=(config, status_queue))
    status_thread.daemon = True
    status_thread.start()

    status_queue.put("started")

    status = "failure"
    try:
        ###################################
        # 5 - Generate Chef configuration #
        ###################################
        _generate_chef_config(is_linux, solo, bootstrap_path, log_path)

        ############################################
        # 6 - Sync Chef repos to disk and run Chef #
        ############################################
        flags = ""
        if debug:
            flags = "-l debug"

        if solo:
            if no_sync is False:
                _sync_chef_repos(is_linux, bootstrap_path, log_path)
            _run_chef_solo(is_linux, log_path, flags)
        else:
            _run_chef_client(is_linux, log_path, flags)

        status = "success"

    finally:
        status_queue.put(status)
        status_thread.join()
        
        # Clean up the converge.pid since the process has ended
        if os.path.isfile(pid_file):
            os.remove(pid_file)
