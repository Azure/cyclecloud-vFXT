from StringIO import StringIO
import base64
import gzip
from hashlib import md5
from Crypto.Cipher import AES
from collections import defaultdict
import re
from xml.etree import cElementTree as ET
import os
import urllib2
import socket
import json
from xml.dom.minidom import parse
import binascii
import logging

logger = logging.getLogger()

import jetpack.util


def etree_to_dict(t):
    d = {t.tag: {} if t.attrib else None}
    children = list(t)
    if children:
        dd = defaultdict(list)
        for dc in map(etree_to_dict, children):
            for k, v in dc.iteritems():
                dd[k].append(v)
        d = {t.tag: {k: v[0] if len(v) == 1 else v for k, v in dd.iteritems()}}
    if t.attrib:
        d[t.tag].update((k, v) for k, v in t.attrib.iteritems())
    if t.text:
        text = t.text.strip()
        if children or t.attrib:
            if text:
                d[t.tag]['#text'] = text
        else:
            d[t.tag] = text
    return d


def unpad(s):
    """ Remove PKCS5 padding. """
    return s[0:-ord(s[-1])]


class Userdata():
    def __init__(self):
        self.key = "c1fb884484645b549e93ca6bb311d719b3c933d1bea81935079b89d99466f3f0"
        self.userdata_raw = None
        self.provider = jetpack.util.get_provider()
        self.userdata_hash = ""
        self.userdata_xml = ""

    def fetch(self):
        """ Fetch the data from the provider's storage if hasn't already been set. """
        # TODO: This needs error handling.
        if self.provider == 'azure':
            if os.name == 'nt':
                filename = 'C:\\AzureData\\CustomData.bin'
                # NOTE: On Azure+Windows the CustomData file is binary
                data = open(filename, 'rb').read()
            else:
                filename = '/var/lib/waagent/CustomData'
                if not os.path.exists(filename):
                    filename = '/var/lib/waagent/ovf-env.xml'
                    tree = parse("/var/lib/waagent/ovf-env.xml")
                    data = binascii.a2b_base64(tree.getElementsByTagNameNS("*", "CustomData")[0].childNodes[0].data)
                else:
                    # NOTE: On Linux CustomData file is b64 encoded unlike windows
                    data = binascii.a2b_base64(open(filename).read())
            logger.info('Fetched raw userdata from %s' % filename)
        elif self.provider == 'aws':
            url = "http://169.254.169.254/latest/user-data"
            data = urllib2.urlopen(url).read()
            logger.info('Fetched raw userdata from %s' % url)
        elif self.provider == 'gce':
            url = "http://169.254.169.254/computeMetadata/v1/instance/attributes/cyclecloud-config"
            request = urllib2.Request(url, None, {"Metadata-Flavor": "Google"})
            data = urllib2.urlopen(request).read()
            data = binascii.a2b_base64(data)
            logger.info('Fetched raw userdata from %s' % url)
        else:
            raise Exception("Unknown Provider: Unable to fetch raw userdata for provider: %s" % self.provider)
        return data

    def gunzip(self, data):
        """ Unzip the data. """
        f = gzip.GzipFile(fileobj=StringIO(data))
        unzipped_data = f.read()
        f.close()
        logger.debug('Unzipped userdata.')
        return unzipped_data

    def _derive_key_and_iv(self, password, salt, key_length, iv_length):
        """ Generate the key and iv based on the password and salt"""
        d = d_i = ''
        while len(d) < key_length + iv_length:
            d_i = md5(d_i + password + salt).digest()
            d += d_i
        return d[:key_length], d[key_length:key_length + iv_length]

    def decrypt(self, encrypted_data):
        """ decrypt the encrypted user-data which is currently in xml format
        """
        # Need to decode before decrypt
        data = base64.b64decode(encrypted_data)

        # there are problems if it isn't properly salted
        if not data or len(data) < 16 or data[0:8] != 'Salted__':
            return ""

        # seperate salt from data
        salt = data[8:16]
        data = data[16:]

        # Using these settings for current encryption
        # TODO: should move these elsewhere
        key_length = 16
        iv_length = 16
        key, iv = self._derive_key_and_iv(self.key, salt, key_length, iv_length)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        result = cipher.decrypt(data)
        # strip padding
        result = unpad(result)
        logger.debug('Decrypted userdata.')
        return result

    def get(self):
        if not self.userdata_raw:
            self.userdata_raw = self.fetch()

        unzipped_data = self.gunzip(self.userdata_raw)
        self.userdata_xml = self.decrypt(unzipped_data)

    def to_xml(self):
        if not self.userdata_xml:
            self.get()
        return self.userdata_xml

    def to_dict(self):
        """ convert the xml to dictionary. """
        if not self.userdata_xml:
            self.to_xml()
        if not self.userdata_hash:
            # remove the namespace
            xml = re.sub(' xmlns="[^"]+"', '', self.userdata_xml, count=1)
            e = ET.XML(xml)
            self.userdata_hash = etree_to_dict(e)
        return self.userdata_hash

    def to_json(self):
        """ convert the dictionary to valid json.
            NOTE: we have to add quite a bit of additional helper data to the json.
            NOTE: we also are renaming the top-level key. """
        if not self.userdata_hash:
            self.to_dict()

        # We need to convert the top-level user-data key to user_data
        self.userdata_hash['user_data'] = self.userdata_hash.pop('user-data')

        # we're going to be manipulating the user-data
        ud = self.userdata_hash

        # Add a runlist
        ud['user_data']['run_list'] = self.runlist()

        # save the updated version
        self.userdata_hash = ud
        json_data = json.dumps(self.userdata_hash, indent=2)
        logger.debug("Converted raw userdata to json format.")
        return json_data

    def runlist(self):
        """ Create a runlist from the user data - this is mostly legacy it's more of a client-config for chef. """
        ud = self.userdata_hash
        data = {}
        data['run_list'] = []
        if 'chefAttributes' in ud['user_data'] and 'image' in ud['user_data']['chefAttributes']:
            if type(ud['user_data']['chefAttributes']['image']['attr']) is list:
                level_list = ud['user_data']['chefAttributes']['image']['attr']
            else:
                level_list = [ud['user_data']['chefAttributes']['image']['attr']]
            for attr in level_list:
                if attr['name'] == 'run_list':
                    data['run_list'] += json.loads(attr['value'])
                else:
                    data[attr['name']] = json.loads(attr['value'])

        # Automatically add "cyclecloud" and "cluster_init" to runlists if they aren't already in there
        if "recipe[cyclecloud]" not in data['run_list']:
            data['run_list'].insert(0, "recipe[cyclecloud]")
        if "recipe[cluster_init]" not in data['run_list']:
            data['run_list'].append("recipe[cluster_init]")
        return json.dumps(data)
