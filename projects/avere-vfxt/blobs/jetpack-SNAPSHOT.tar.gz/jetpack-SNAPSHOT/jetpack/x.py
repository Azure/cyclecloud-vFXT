import click
import platform
import os
import util
import traceback
import logging
import logging.handlers
import cli
import sys



if __name__ == "__main__":
    #cli.config_command(["chef_handler", "EMPTY", "-j", "/Users/michael/node.json"]) #,None,"/Users/michael/node.json"])
	#cli.config_command(["cyclecloud.blackboard", "-j", "/Users/michael/node.json"])
	#cli.config_command(["kernel.modules","EMPTY","-j", "/Users/michael/node.json"])
	#cli.config_command(["cyclecloud.instance.provider","EMPTY","-j", "/Users/michael/node.json"])
	print(sys.argv)
	if len(sys.argv) < 2:
		print("executing: jetpack config")
		cli.config_command(["-j", "/Users/michael/node.json"])
	else:
		x = sys.argv[1]
		print("executing: jetpack config %s" % sys.argv[1])	
		cli.config_command([sys.argv[1],"--json","-j", "/Users/michael/node.json"])
	

