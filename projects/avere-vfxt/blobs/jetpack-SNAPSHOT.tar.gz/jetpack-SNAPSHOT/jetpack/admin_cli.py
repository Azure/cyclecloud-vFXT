import click


@click.group()
def admin():
    pass


@admin.command(name='configure', help="Configures jetpack")
@click.option('--user-data', type=click.Path(), help="Path to the user data file on the node")
@click.option('--jetpack-config', type=click.Path(), help="Path to the jetpack config file to write")
def configure_command(user_data, jetpack_config):
    import admin.configure
    try:
        admin.configure.execute(user_data, jetpack_config)
    except admin.configure.JetpackConfigureError as e:
        raise click.ClickException(e.message)
    except Exception:
        raise click.ClickException("An unknown error occurred")


# @admin.command(name='chef-shell', help="Opens a chef-shell for Jetpack")
# def chef_shell_command():
#     pass

if __name__ == "__main__":
    admin()
