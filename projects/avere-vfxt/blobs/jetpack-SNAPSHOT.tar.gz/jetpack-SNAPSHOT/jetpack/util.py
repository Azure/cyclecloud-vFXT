import os
import platform
import ctypes
import httplib
import datetime
import time


def _is_azure():
    return os.path.exists("C:\\AzureData\\CustomData.bin") or os.path.exists("/var/lib/waagent/CustomData") or os.path.exists("/var/lib/waagent/ovf-env.xml")


def _is_aws():
    try:
        conn = httplib.HTTPConnection("169.254.169.254", timeout=2)
        conn.request("GET", "latest/meta-data/")
        res = conn.getresponse()
        if res.status == 200:
            return True
    except:
        pass
    return False


def _is_gce():
    try:
        conn = httplib.HTTPConnection("169.254.169.254", timeout=2)
        conn.request("GET", "computeMetadata/v1")
        res = conn.getresponse()
        return res.getheader('Metadata-Flavor', "").lower() == "google"
    except:
        pass
    return False


def get_provider():
    """ Attempts to determine the CSP the machine is currently using """
    if _is_azure():
        return "azure"
    elif _is_aws():
        return "aws"
    elif _is_gce():
        return "gce"
    else:
        return None


def pid_running(pid):
    """ Given a pid (int) check with the OS to see if it is currently running """
    if platform.system().lower().startswith("win"):
        kernel32 = ctypes.windll.kernel32
        SYNCHRONIZE = 0x100000

        process = kernel32.OpenProcess(SYNCHRONIZE, 0, pid)
        if process != 0:
            kernel32.CloseHandle(process)
            return True
        else:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
            

def stale_file(pid_file):
    """ Check the last boot time vs the modified time of the pid file to see
    if it's a stale file """
    if not os.path.isfile(pid_file):
        return False

    last_modified = datetime.datetime.fromtimestamp(os.path.getmtime(pid_file))
    
    if platform.system().lower().startswith("win"):
        kernel32 = ctypes.windll.kernel32
        kernel32.GetTickCount64.restype = ctypes.c_uint64
        uptime = kernel32.GetTickCount64() / 1000.0
    else:
        with open('/proc/uptime', 'r') as f:
            uptime = float(f.readline().split()[0])
    
    boottime = datetime.datetime.fromtimestamp(time.time() - uptime)
    if boottime >= last_modified:
        return True 
    else:
        return False


def already_running(pid_file=None):
    """ Given a path to a pid file, check to see if the pid in the file is running:
      * if yes - return True as the process is already running
      * if no - return False as the process is no longer running
      * if no pid file exsits - write one for the current process
     """
    pid = None

    # Read the pid from the file if it exists and isn't stale
    if os.path.isfile(pid_file) and not stale_file(pid_file):
        with open(pid_file) as f:
            pid = int(f.read())

    # If no pid file was read, or it was read and the process is no longer running
    # return false and write the current pid to the file
    if pid is None or (pid and not pid_running(pid)):
        with open(pid_file, 'w') as f:
            f.write(str(os.getpid()))
        return False

    # If the pid exists and it is running, return True - nothing to see here
    else:
        return True


def _config_to_dict(config_parser):
    # Convert parser to dictionary
    cfg = {}
    for section_name in config_parser.sections():
        section = {}
        for option in config_parser.options(section_name):
            section[option] = config_parser.get(section_name, option)
        cfg[section_name] = section

    return cfg


def _get_config_file(config=None):
    if config is None:
        config = '/opt/cycle/jetpack/config/jetpack.ini'
        if platform.system().lower().startswith('win'):
            config = 'C:\cycle\jetpack\config\jetpack.ini'
    config = os.path.expanduser(config)
    return config


def _transform_dict_to_ini(config_dict):
    """ Converts a config dictionary into an .ini file """
    def _format_section(name, section):
        section = '\n'.join(["%s=%s" % (k, v) for k, v in section.iteritems()])
        return "[%s]\n%s" % (name, section)

    config_ini = '\n\n'.join([_format_section(k, v) for k, v in config_dict.iteritems()])

    return config_ini


def parse_config(config=None):
    config = _get_config_file(config)
    if not os.path.isfile(config):
        return {}

    # Now read the config file
    import ConfigParser
    parser = ConfigParser.RawConfigParser()
    parser.read(config)

    return _config_to_dict(parser)


def write_config(config_dict, config=None):
    config = _get_config_file(config)
    config_ini = _transform_dict_to_ini(config_dict)

    config_dir = os.path.dirname(config)
    if not os.path.exists(config_dir):
        os.makedirs(config_dir)

    with open(config, 'w') as f:
        f.write(config_ini)
