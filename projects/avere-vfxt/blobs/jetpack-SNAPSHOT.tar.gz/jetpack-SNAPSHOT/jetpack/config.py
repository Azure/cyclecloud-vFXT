import os
UNKNOWN_ERROR = "An unknown error occurred while processing the configuration data file."


class ConfigError(Exception):
    pass


def get(value=None, default=None, configuration_file=None):
    try:
        current_val = _get_data(configuration_file)
        if value is None:
            return current_val
        properties = value.split('.')
        for prop in properties:
            current_val = current_val[str(prop)]
        return current_val
    except KeyError:
        if default:
            return default
        else:
            raise ConfigError("The value '%s' was not found in the node configuration." % value)
    except Exception:
        raise ConfigError(UNKNOWN_ERROR)


def _config_file():
    """ Get the node.json configuration based on the OS """
    import platform
    if platform.system().lower().startswith("win"):
        return "C:\\cycle\\jetpack\\config\\node.json"
    else:
        return "/opt/cycle/jetpack/config/node.json"


def _get_data(config_file=None):
    """ Return a dictionary of data from a config file """
    import json
    if config_file is None:
        config_file = _config_file()

    config_file = os.path.expanduser(config_file)
    try:
        with open(config_file) as f:
            data = json.loads(f.read())
            return data
    except IOError as e:
        raise ConfigError(e.strerror)
    except ValueError as e:
        raise ConfigError(e.message)
    except Exception as e:
        raise ConfigError(UNKNOWN_ERROR)
