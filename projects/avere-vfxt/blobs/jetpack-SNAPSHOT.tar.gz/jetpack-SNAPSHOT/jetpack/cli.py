import click
import platform
import os
import util
import traceback
import json
import logging
import logging.handlers
import logging.config

NESTED_INDICATOR = "<nested>"

# Handler to set ownership for the rotated log files
# See python docs: http://python.readthedocs.org/en/latest/howto/logging-cookbook.html
def owned_file_handler(filename, owner=None):
    if owner:  # TODO: and not windows?
        if not os.path.exists(filename):
            open(filename, 'a').close()
        
        # Set the filesystem ownership of newly created log files if we are on linux
        if not platform.system().lower().startswith("win"):
            import pwd
            uid = pwd.getpwnam("cyclecloud").pw_uid
            gid = pwd.getpwnam("cyclecloud").pw_gid
            os.chown(filename, uid, gid)
    return logging.handlers.RotatingFileHandler(filename, backupCount=5, maxBytes=10485740)


def _cyclecloud_home():
    default_cyclecloud_home = 'C:\\cycle\\jetpack' if platform.system().lower().startswith("win") else '/opt/cycle/jetpack'
    return default_cyclecloud_home

    
def _handle_exception():
    logger = logging.getLogger()
    logger.error(traceback.format_exc())
    raise click.ClickException("An unknown error occurred, please see jetpack.log for details.")


# Note: Not sure the params here, taken from docs
def _print_version(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return

    default_cyclecloud_home = _cyclecloud_home()
    version_file = os.path.join(default_cyclecloud_home, 'version.txt')
    try:
        if os.path.exists(version_file):
            with open(version_file, 'r') as f:
                version = f.read().strip()
                click.echo("%s" % version)
        else:
            raise Exception()
    except:
        raise click.ClickException("Unable to read version in %s" % version_file)
    ctx.exit()


def _setup_logging(loglevel):
    cyclecloud_home = _cyclecloud_home()
    logfile = os.path.join(cyclecloud_home, 'logs', 'jetpack.log')
    
    LOGGING = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'default': {
                'format': '%(asctime)s %(levelname)-8s %(message)s'
            },
        },
        'handlers': {
            'file': {
                # The values below are popped from this dictionary and
                # used to create the handler, set the handler's level and
                # its formatter.
                '()': owned_file_handler,
                'level': loglevel.upper(),
                'formatter': 'default',
                # The values below are passed to the handler creator callable
                # as keyword arguments.
                'owner': ['cyclecloud', 'cyclecloud'],
                'filename': logfile,
            },
        },
        'root': {
            'handlers': ['file'],
            'level': loglevel.upper(),
        },
    }

    logging.config.dictConfig(LOGGING)

def _format_dict(_dict,_val=None):
    results = {}
    for _k in _dict.keys():
        subdict = _dict[_k]
        if isinstance(subdict, dict):
            attrib = NESTED_INDICATOR
        else:
            attrib = subdict
        if _val:
            formatted_key = "%s.%s" % (_val,_k)
        else:
            formatted_key = "%s" % _k
        results[formatted_key] = attrib
    formatted_keys = ""
    _configs = sorted(results.keys())
    max_key_length = len(max(_configs, key=len))
    for _config in _configs:
        formatted_key = _config.ljust(max_key_length)
        formatted_keys += "\n  %s = %s" % (formatted_key, results[_config])
    return formatted_keys



@click.group()
@click.option('--loglevel', type=click.Choice(["debug", "info", "warn"]), default='info')
@click.option('-c', '--config', type=click.Path(), help="Jetpack configuration file")
@click.option('-v', '--version', is_flag=True, callback=_print_version, expose_value=False, is_eager=True, help="Version information for this program")
@click.pass_context
def jetpack(ctx, loglevel, config=None):
    ctx.obj = {}
    ctx.obj['config'] = util.parse_config(config)
    
    _setup_logging(loglevel)


@jetpack.command(name='keepalive', short_help="Delays the healthcheck daemon")
@click.argument('duration', required=False)
def keepalive_command(duration=None):
    """
    Delays the healthcheck daemon from terminating the system for a specified period of time.

    DURATION defaults to 1 hour if not specified

    Valid values for DURATION are of the format n{m,h,d} where n is an integer and {m,h,d} are time units.
    "h" is the default time unit if no time unit specified

    time units:
    m - minutes
    h - hours
    d - days

    \b
    Examples:
    $ jetpack keepalive            # system will be kept alive for 1 hour
    $ jetpack keepalive forever    # healthservice will be disabled and system will stay up indefinitely
    $ jetpack keepalive 2d         # system will be kept alive for 2 days
    """
    import keepalive
    try:
        msg = keepalive.execute(duration)
        click.echo(msg)
    except keepalive.KeepaliveError as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except Exception:
        _handle_exception()


@jetpack.command(name='config')
@click.argument('value', required=False)
@click.argument('default', required=False)
@click.option('-j', '--json-file', type=click.Path(), default=None, help="Non-default node configuration file to use")
@click.option('--json','as_json', is_flag=True, help="Output data in serial json format")
def config_command(value, default, json_file, as_json):
    """Gets a configuration value"""

    import config
    
    # Find the deepest valid configuration
    if value:
        properties = value.split('.')
    else:
        properties = []
    while True:
        _key = '.'.join(properties)        
        if _key == "":
            _key = None
        try:
            v = config.get(_key, default, configuration_file=json_file)
        except config.ConfigError as e:
            if _key == None or as_json:
                raise click.ClickException(e.message)
            else:
                properties.pop()
                continue
        break

    if as_json:
        if not(isinstance(v,dict)):
            # Force into valid dict for json module, if only a single value.
            v = {value : v}
        if _key != value:
            raise click.ClickException("The value '%s' was not found in the node configuration." % value)
        click.echo(json.dumps(v,indent=4))
        return

    err = False
    MSG = []
    if isinstance(v,dict):
        MSG.append("The value '%s' contains nested values." % _key)
        output = _format_dict(v,_val=_key)
        err = True
    else:
        output = str(v)
    if value != _key:
        MSG.append("The value '%s' was not found in the node configuration." % value)
        if _key:
            MSG.append("  Reporting results for '%s'" % _key)
        err = True
    if _key == None:
        MSG.append("  Reporting top level options.")
        err = True
    if err:
        MSG.append(output)
        raise click.ClickException('\n'.join(MSG) + "\n")
    else:
        click.echo(output)


@jetpack.command(name='converge')
@click.option('--debug', is_flag=True, help="Run in debug mode")
@click.option('--no-sync', is_flag=True, help="Do not sync Chef repositories before executing converge")
def converge_command(debug, no_sync):
    """Triggers a converge on the current node"""
    try:
        import converge
        converge.execute(debug=debug, no_sync=no_sync)
    except converge.ConvergeError as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except:
        _handle_exception()

    click.echo("Node converged successfully")


@jetpack.command(name='log')
@click.argument('message')
@click.option('-l', '--level', default='info', type=click.Choice(['info', 'warn', 'error']), help="Type of log message you wish to send. Default: info")
@click.option('-p', '--priority', type=click.Choice(['low', 'medium', 'high']), help="""
Priority of message to send to CycleCloud. Default depends on the level chosen. Info messages get a priority of 'medium', warn messages 'medium', and error messages 'high'""")
@click.pass_context
def log_command(ctx, message, level, priority=None):
    """Sends log message to CycleCloud"""
    import amqp
    try:
        amqp.log(message, level, priority, config=ctx.obj['config'])
    except amqp.LogError as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except Exception:
        _handle_exception()


@jetpack.command(name='send')
@click.option('-m', '--message', help="The message to send")
@click.option('-f', '--file', type=click.Path(), help="The file to send.")
@click.option('-r', '--routing-key', default=None, help="The amqp routing-key associated with the message")
@click.pass_context
def send_command(ctx, message, file, routing_key):
    """ Sends a message to CycleCloud """
    import amqp
    try:
        amqp.send(message=message, file=file, routing_key=routing_key, config=ctx.obj['config'])
    except amqp.SendError as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except Exception:
        _handle_exception()


@jetpack.command(name='direct_publish')
@click.option('-q', '--queue_name', default=None, help="The Queue name for simple direct queue")
@click.option('-m', '--message', default=None, help="The message to send")
@click.option('-c', '--clear', is_flag=True, help="Clear messages from queue")
@click.pass_context
def direct_publish_command(ctx, message, queue_name, clear):
    """ Sends a message to CycleCloud """
    import amqp
    try:
        amqp.direct_publish(message=message, queue_name=queue_name, clear=clear, config=ctx.obj['config'])
    except amqp.SendError as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except Exception:
        _handle_exception()

@jetpack.command(name='direct_get')
@click.option('-q', '--queue_name', default=None, help="The amqp routing-key associated with the message")
@click.option('-s', '--size_only', is_flag=True, help="Only return the queue size")
@click.pass_context
def direct_get_command(ctx, queue_name, size_only):
    """ Sends a message to CycleCloud """
    import amqp
    try:
        r = amqp.direct_get(queue_name=queue_name, size_only=size_only, config=ctx.obj['config'])
        click.echo("{}".format(r))
    except amqp.SendError as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except Exception:
        _handle_exception()


@jetpack.command(name='test')
@click.option('-d', '--directory', default=".", help="The directory where test files are located")
@click.option('-r', '--results', type=click.Path(), help="File to write results to")
@click.pass_context
def test_command(ctx, directory, results):
    """ Runs python style unittests on the node """
    import tests
    try:
        if tests.run(directory, results) is False:
            ctx.exit(1)  # The tests failed, bail
    except tests.JetpackTestException as e:
        raise click.ClickException(e.message)
    except click.ClickException as e:
        raise e
    except Exception:
        _handle_exception()

@jetpack.command(name='autoscale')
@click.option('-f', '--file', type=click.Path(exists=True), help="JSON formatted file containing a list of nodearray definitions.")
@click.option('-n', '--name', default='execute', help="The name of a nodearray to autoscale.")
@click.option('-c', '--corecount', type=click.INT, default=None, help="The number of cores to autoscale the nodearray to.")
@click.pass_context
def autoscale_command(ctx, file, name, corecount):
    """ Autoscales the cluster the node is part of """
    import autoscale
    if file:
        try:
            arrays = json.load(open(file))
            autoscale.update(arrays)
        except ValueError:
            raise click.ClickException("The file specified does not appear to be valid json")
        
    elif name is not None and corecount is not None:
        autoscale.set(name, corecount)
    else:
        raise click.ClickException("Please specify either a file, or an array name and target count - see help for details.")


if __name__ == "__main__":
    jetpack()
