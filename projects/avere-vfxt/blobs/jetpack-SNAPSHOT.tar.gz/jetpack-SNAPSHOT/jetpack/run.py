import click
import platform
import os
import util
import traceback
import logging
import logging.handlers
import cli


if __name__ == "__main__":
    #cli.config_command(["chef_handler", "EMPTY", "-j", "/Users/michael/node.json"]) #,None,"/Users/michael/node.json"])
	#cli.config_command(["cyclecloud.blackboard", "-j", "/Users/michael/node.json"])
	#cli.config_command(["kernel.modules","EMPTY","-j", "/Users/michael/node.json"])
	cli.config_command(["cyclecloud.instance.provider","EMPTY","-j", "/Users/michael/node.json"])
