import unittest
import StringIO
import sys
import jetpack.amqp
import json
from jetpack import util


class JetpackTestException(Exception):
    pass


def run(directory=".", results=None, config=None):
    """ Run a test suite specified in 'directory', writing results to a path specified by 'results'"""
    config = util.parse_config(config)

    output = StringIO.StringIO()
    suite = unittest.TestLoader().discover(start_dir=directory, pattern="test_*.py")
    runner = unittest.TextTestRunner(stream=output)
    result = runner.run(suite)
    
    # Write the results to file
    if results:
        with open(results, 'w') as f:
            f.write(output.getvalue())
        
    # Write the results to stderr as usual for unittests
    sys.stderr.write(output.getvalue())

    # Send the results back to CycleCloud via AMQP bus
    # TODO: We should send other stats like, time to run, etc.
    message = {
        'errors': [],
        'failures': []
    }
    for error in result.errors:
        message['errors'].append({
            'message': 'ERROR: %s' % str(error),
            'traceback': error[1]
        })
    for failure in result.failures:
        message['failures'].append({
            'message': 'FAIL: %s' % str(failure),
            'traceback': failure[1]
        })
    
    jetpack.amqp.send(message=json.dumps(message), routing_key='cyclecloud.test.results', config=config)
       
    # Raise an exception on test failures
    if not result.wasSuccessful():
        jetpack.amqp.log("Cluster test results: %s errors, %s failures." % (len(result.errors), len(result.failures)), "error", config=config)
        return False
    return True
