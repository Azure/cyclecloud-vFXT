import json

from kombu import Connection
from kombu import Exchange
from kombu import Producer
from kombu import Consumer
from kombu import Queue
from kombu.exceptions import ContentDisallowed

import pdb


# defaults simply demonstrate the keys used.  They are not valid for specific connections.
_default_config = {
    'host': "localhost",
    'port': 5672,
    'username': "guest",
    'password': "guest",
    'virtual_host': "/",
    'exchange': '',
    'exchange_type': 'direct',
    'routing_key': '',
}


class AmqpConnection(object):

    def __init__(self, name, config):

        self.name = name
        self.config = config
        self.connection = None
        self.channel = None

        for key in _default_config:
            if key not in self.config:
                self.config[key] = _default_config[key]

        self.config["port"] = int(self.config["port"])  # Ensure that port is an int

    def __del__(self):
        self.close()

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, type, value, traceback):
        self.close()

    def open(self):
        if not self.connection:
            # Open connection to the bus
            self.connection = Connection(hostname=self.config["host"],
                                         port=self.config["port"],
                                         virtual_host=self.config["virtual_host"],
                                         userid=self.config["username"],
                                         password=self.config["password"])
            self.connection.connect()
        else:
            raise Exception("connection already open")

    def send_json(self, body, exchange=None, exchange_type=None, routing_key=None, headers=None):
        '''Helper for formatting and sending simple messages in json format.'''
        self.send(json.dumps(body), exchange, exchange_type, routing_key, headers)

    def send(self, body, exchange=None, exchange_type=None, routing_key=None, headers=None):
        if self.connection:
            '''Send a pre-formatted message.'''

            if not exchange:
                exchange = self.config["exchange"]
            if not exchange_type:
                exchange_type = self.config["exchange_type"]
            if not routing_key:
                routing_key = self.config["routing_key"]

            exch_obj = Exchange(exchange, type=exchange_type)

            prod_obj = Producer(self.connection)

            prod_obj.publish(body, exchange=exch_obj, routing_key=routing_key, headers=headers)

        else:
            raise Exception("failed sending amqp message, connection not open")

    def direct_publish(self, body, simpleq="default", clear=False):
        if self.connection:
            queue = self.connection.SimpleQueue(simpleq)
            if clear:
                print("clearing queue")
                queue.clear()
                queue.close()
                return
            payload = { "msg" : body }
            queue.put(payload)
            queue.close()
            return

    def direct_get(self, simpleq="default",size_only=False):
        if self.connection:
            queue = self.connection.SimpleQueue(simpleq)
            if size_only:
                return queue.qsize()
            while 1:
                try:
                    message = queue.get(block=True, timeout=1)
                    message.ack()
                    payload = json.loads(message.body)
                    break
                except ContentDisallowed as e:
                    print("raising: {}".format(e))
                except Empty as e:
                    print("raising: {}".format(e))
            queue.close()
            return payload["msg"]

    def close(self):

        conn = self.connection
        self.connection = None
        if conn:
            conn.close()
