# Copyright 2014, Cycle Computing
# All rights reserved - Do Not Redistribute
#
import json
import os
import platform
import urllib
import jetpack.util
import urllib2


class JetpackConfigureError(Exception):
    pass


class JetpackConfigure(object):

    def __init__(self):
        self.cyclecloud_home = ""
        self.cyclecloud_bootstrap = ""

    def _set_paths(self):
        # Determine the home and bootstrap directories
        self.cyclecloud_home = 'C:\\cycle\\jetpack' if platform.system().lower().startswith("win") else '/opt/cycle/jetpack'
        self.cyclecloud_bootstrap = os.path.join(self.cyclecloud_home, "system", "bootstrap")

        self.cyclecloud_home = os.environ.get('CYCLECLOUD_HOME', self.cyclecloud_home)
        self.cyclecloud_bootstrap = os.environ.get('CYCLECLOUD_BOOTSTRAP', self.cyclecloud_bootstrap)

    def _read_user_data(self, user_data_path=None):
        if not user_data_path:
            user_data_path = os.path.join(self.cyclecloud_bootstrap, 'user-data.json')

        user_data = {}
        with open(user_data_path, 'r') as f:
            user_data = json.loads(f.read())
        if 'user_data' in user_data:
            return user_data['user_data']  # currently user data is nested
        else:
            return user_data

    def _get_instance_id_aws(self, userdata=None):
        r = urllib.urlopen("http://169.254.169.254/latest/meta-data/instance-id/")
        if r.getcode() == 200:
            return r.read()
        else:
            return "unknown"

    def _get_instance_id_azure(self, userdata):
        run_list = json.loads(userdata['run_list'])

        # Verify cyclecloud.isntance exists
        try:
            # Get the instance ID if defined and use it
            instance_id = run_list['cyclecloud']['instance']['id']
        except KeyError:
            # Otherwise generate the key based on the RoleID + Cloud service
            try:
                cloud_service = run_list['cyclecloud']['instance']['cloud_service']
                try:
                    role_instance_id = os.environ['Azure_RoleInstanceId']
                except KeyError:
                    raise JetpackConfigureError("Cannot generate instance ID: cyclecloud.instance.cloud_service is set but Azure_RoleInstanceId env is not!")
                instance_id = "%s-%s" % (cloud_service, role_instance_id)
            except KeyError:
                raise JetpackConfigureError("Cannot generate instance ID: Neither cyclecloud.instance.id nor cyclecloud.instance.cloud_service is set!")

        return instance_id

    def _get_instance_id_gce(self):
        try:
            url = "http://169.254.169.254/computeMetadata/v1/project/project-id"
            request = urllib2.Request(url, None, {"Metadata-Flavor": "Google"})
            project_id = urllib2.urlopen(request).read()

            url = "http://169.254.169.254/computeMetadata/v1/instance/attributes/instance-name"
            request = urllib2.Request(url, None, {"Metadata-Flavor": "Google"})
            name = urllib2.urlopen(request).read()

            return "%s@gcp-%s" % (name, project_id)
        except:
            raise JetpackConfigureError("Unable to determine GCE instance id!")

    def _get_instance_id(self, userdata=None):
        provider = jetpack.util.get_provider()
        if provider == "azure":
            return self._get_instance_id_azure(userdata)
        elif provider == "aws":
            return self._get_instance_id_aws()
        elif provider == "gce":
            return self._get_instance_id_gce()
        else:
            raise Exception("Could not get instanceId for provider '%s'" % provider)

    def _transform_userdata_to_dict(self, user_data):
        amqp_settings = {}

        if "user" in user_data["rabbitmq"]:
            amqp_settings["username"] = user_data["rabbitmq"]["user"]
        if "password" in user_data["rabbitmq"]:
            amqp_settings["password"] = user_data["rabbitmq"]["password"]
        if "vhost" in user_data["rabbitmq"]:
            amqp_settings["virtual_host"] = user_data["rabbitmq"]["vhost"]
        if "hostname" in user_data["rabbitmq"]:
            amqp_settings["host"] = user_data["rabbitmq"]["hostname"]
        if "port" in user_data["rabbitmq"]:
            amqp_settings["port"] = user_data["rabbitmq"]["port"]

        config_dict = {}
        config_dict["amqp"] = amqp_settings

        identity_settings = {}
        identity_settings["cluster_name"] = user_data["pool"]["name"]
        identity_settings["instance_id"] = self._get_instance_id(user_data)
        config_dict["identity"] = identity_settings

        # TODO: Add in hostname, username, password?
        cs_settings = {}
        cs_settings['webserver'] = user_data['config']['webServer']
        run_list = json.loads(user_data['run_list'])
        cs_settings['api_username'] = run_list['cyclecloud']['config']['username']
        cs_settings['api_password'] = run_list['cyclecloud']['config']['password']
        config_dict["cycle_server"] = cs_settings

        return config_dict

    def run(self, user_data_path=None, jetpack_config=None):
        self._set_paths()
        user_data = self._read_user_data(user_data_path)

        config_dict = self._transform_userdata_to_dict(user_data)

        jetpack.util.write_config(config_dict, jetpack_config)


def execute(user_data_path=None, jetpack_config=None):
    jetpack_configure = JetpackConfigure()
    jetpack_configure.run(user_data_path=user_data_path, jetpack_config=jetpack_config)

    return jetpack.util.parse_config(jetpack_config)
