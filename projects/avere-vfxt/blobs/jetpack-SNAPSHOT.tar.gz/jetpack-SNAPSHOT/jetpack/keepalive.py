import platform
import subprocess
import re
import glob


class KeepaliveError(Exception):
    pass


def _announce_stay_of_execution(stay_of_execution):
    if stay_of_execution == '0':
        return 'The healthcheck service will be terminated and this instance will stay alive indefinitely'
    else:
        if stay_of_execution.endswith('m'):
            time_unit = "minute"
        elif stay_of_execution.endswith('d'):
            time_unit = "day"
        elif stay_of_execution.endswith('h'):
            time_unit = "hour"
        else:
            raise KeepaliveError("Invalid duration")

        stay_of_execution_num = stay_of_execution[0:-1]
        return "Termination of this node will be delayed by %s %s(s)" % (stay_of_execution_num, time_unit)


def _process_duration(stay_of_execution):
    if not stay_of_execution:
        stay_of_execution = '1h'

    stay_of_execution = stay_of_execution.lower()

    if stay_of_execution == 'forever':
        stay_of_execution = '0'
    else:
        time_regex = r"""^\d+[mdh]?$"""
        if re.match(time_regex, stay_of_execution) is None:
            raise KeepaliveError("The value you provided for a duration '%s' is invalid" % stay_of_execution)

    return stay_of_execution


def _keepalive_windows(stay_of_execution):
    if stay_of_execution != "0":
        raise KeepaliveError("Windows keepalive does not support time periods")
    cmd = "schtasks /delete /f /tn HealthCheck"
    try:
        subprocess.Popen(cmd, shell=True)
    except:
        raise KeepaliveError("Failed to disable healthcheck")


def _keepalive_linux(stay_of_execution):
    # WHY IS THIS THE FILE? Clear part of the deamon but we should document it.
    healthcheck_glob = glob.glob('/tmp/healthcheck*/healthcheck')
    if len(healthcheck_glob) < 1:
        raise KeepaliveError('Could not communicate with healthcheck daemon. Is it running?')
    else:
        fifo_path = healthcheck_glob[0]
        fifo = open(fifo_path, 'a')
        fifo.write(stay_of_execution)
        fifo.close()


def execute(stay_of_execution=None):
    stay_of_execution = _process_duration(stay_of_execution)

    if platform.system().lower().startswith('win'):
        _keepalive_windows(stay_of_execution)
    else:  # Linux
        _keepalive_linux(stay_of_execution)

    return _announce_stay_of_execution(stay_of_execution)
