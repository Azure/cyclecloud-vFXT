import os
import time
from amqp_connection import AmqpConnection


DEFAULT_EXCHANGE = "cyclecloud.top"
DEFAULT_EXCHANGE_TYPE = "topic"


class SendError(Exception):
    pass


class LogError(Exception):
    pass

def _retry_func(func):
    wait_length = 5
    success = False

    while not success:
        try:
            x = func()
            success = True
        except Exception, e:

            if wait_length < 41: # retry 5 times, waiting 5, 10, 20, then 40 seconds
                time.sleep(wait_length)
                wait_length *= 2
            else:
                raise
    return x

def _retry_func_return(func):
    wait_length = 5
    success = False

    while not success:
        try:
            r = func()
            success = True
        except Exception, e:

            if wait_length < 41: # retry 5 times, waiting 5, 10, 20, then 40 seconds
                time.sleep(wait_length)
                wait_length *= 2
            else:
                raise
    return r

def drain(routing_key=None, config=None):
    """ whatever """ 
    try:
        identity = config["identity"]
        cluster_name = identity["cluster_name"]
        instance_id = identity["instance_id"]
        amqp_config = config["amqp"]

    except KeyError as e:
        raise SendError("Unable to find '%s' in config" % e.message)

    amqp_config["routing_key"] = 'cyclecloud.general'
    amqp_config["exchange"] = "cyclecloud.topic"
    amqp_config["exchange_type"] = "topic"

    headers = {
        "cluster_name": cluster_name,
        "instance_id": instance_id
    }

    #with AmqpConnection("drain_command", amqp_config) as conn:
    #    conn.drain_events(timeout=1)
    print("entering drain func")
    def func():
        with AmqpConnection("drain_command", amqp_config) as conn:
                conn.drain_events(routing_key=routing_key)
                #conn.send(message, routing_key=routing_key, headers=headers)
    _retry_func(func)

    #with Consumer(connection, queues, accept=['json']):
    #    connection.drain_events(timeout=1)

def direct_publish(message=None, queue_name=None, clear=False, config=None):
    """ publish message the SimpleQueue """
    if config is None:
        raise SendError("Expected a configuration dictionary")
    elif not message and not clear :
        raise SendError("No message body specified")

    try:
        identity = config["identity"]
        cluster_name = identity["cluster_name"]
        instance_id = identity["instance_id"]
        amqp_config = config["amqp"]
    except KeyError as e:
        raise SendError("Unable to find '%s' in config" % e.message)

    def func():
        with AmqpConnection("direct_pushlish_command", amqp_config) as conn:
                conn.direct_publish(message, simpleq=queue_name, clear=clear)
    _retry_func(func)


def direct_get(queue_name=None, size_only=False, config=None):
    """ publish message the SimpleQueue """
    if config is None:
        raise SendError("Expected a configuration dictionary")

    try:
        identity = config["identity"]
        cluster_name = identity["cluster_name"]
        instance_id = identity["instance_id"]
        amqp_config = config["amqp"]
    except KeyError as e:
        raise SendError("Unable to find '%s' in config" % e.message)

    def func():
        with AmqpConnection("direct_pushlish_command", amqp_config) as conn:
                x = conn.direct_get(simpleq=queue_name, size_only=size_only)
        return x

    return _retry_func_return(func)

def send(message=None, file=None, routing_key=None, config=None):
    """ Sends a message over an amqp bus

    message: A string containing the message to send
    file: A path to a file containing the message to send
    routing_key: The routing key to use
    config: a dictionary of amqp settings usually read from a configuration file:

       config = {
        'identity': {
            'cluster_name': 'my cluster',
            'instance_id': 'i-1234abcd'
        },
        'amqp': {
            'username': 'guest',
            'password': 'guest',
            'vhost': '/',
            'hostname': 'localhost',
            'port': 5672
        }
       }
    """

    if config is None:
        raise SendError("Expected a configuration dictionary")
    elif not message and not file:
        raise SendError("No message body specified")
    elif message and file:
        raise SendError("Cannot specify both a message and a file at the same time")

    try:
        identity = config["identity"]
        cluster_name = identity["cluster_name"]
        instance_id = identity["instance_id"]
        amqp_config = config["amqp"]

    except KeyError as e:
        raise SendError("Unable to find '%s' in config" % e.message)

    amqp_config["routing_key"] = 'cyclecloud.general'
    amqp_config["exchange"] = "cyclecloud.topic"
    amqp_config["exchange_type"] = "topic"

    headers = {
        "cluster_name": cluster_name,
        "instance_id": instance_id
    }

    if file:
        filename = os.path.expanduser(file)
        with open(filename, 'r') as content_file:
                content = content_file.read()
        message = content

    def func():
        with AmqpConnection("send_message_command", amqp_config) as conn:
                conn.send(message, routing_key=routing_key, headers=headers)
    _retry_func(func)


def _get_priority(level):
    if level == 'info':
        log_priority = 'medium'
    elif level == 'warn':
        log_priority = 'medium'
    elif level == 'error':
        log_priority = 'high'
    else:
        raise LogError("Invalid log level")
    return log_priority


def log(message, level, priority=None, config=None):
    if level not in ["info", "warn", "error"]:
        raise LogError("Invalid level: %s" % level)
    if config is None:
        raise LogError("Expected a configuration dictionary")

    priority = priority or _get_priority(level)

    try:
        identity = config["identity"]
        cluster_name = identity["cluster_name"]
        instance_id = identity["instance_id"]
        amqp_config = config['amqp']

    except KeyError as e:
        raise LogError("Unable to find '%s' in config" % e.message)

    amqp_config["routing_key"] = "cyclecloud.log"
    amqp_config["exchange"] = "cyclecloud.topic"
    amqp_config["exchange_type"] = "topic"

    headers = {
        "cluster_name": cluster_name,
        "instance_id": instance_id
    }

    message = {
        "message": message,
        "cluster_name": cluster_name,
        "instance_id": instance_id,
        "log_level": level,
        "log_priority": priority
    }

    def func():
        with AmqpConnection("log_command", amqp_config) as conn:
            conn.send_json(message, headers=headers)
    _retry_func(func)
