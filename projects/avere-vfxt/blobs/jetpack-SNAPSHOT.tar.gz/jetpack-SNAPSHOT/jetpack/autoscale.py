import urllib
import httplib
import string
import base64
import json
import util
import urlparse


def set(name="execute", corecount=0):
    """ Quick set an array to a target core count """
    arrays = [
        {
            'Name': name,
            'TargetCoreCount': corecount
        }
    ]
    update(arrays)

def update(arrays, request_set=None, expiration_interval=None, config=None):
    """ Set several arrays in bulk """
    config = util.parse_config(config)
    
    webserver = config['cycle_server']['webserver']
    api_username = config['cycle_server']['api_username']
    api_password = config['cycle_server']['api_password']

    cluster_name = config['identity']['cluster_name']
    
    conn = None
    u = urlparse.urlparse(webserver)
    if u[0].lower() == "https":
        conn = httplib.HTTPSConnection(u[1])
    else:
        conn = httplib.HTTPConnection(u[1])
    url = "/cloud/api/autoscale/%s" % urllib.quote(cluster_name)
    
    params = {}
    if expiration_interval:
        params['expiration_interval'] = expiration_interval
    if request_set:
        params['request_set'] = request_set
    url = url + "?" + urllib.urlencode(params)
    
    # Ensure that the body is a list of (of dictionaries)
    if not isinstance(arrays, list):
        body = list(arrays)
    body = arrays

    auth = 'Basic ' + string.strip(base64.encodestring(api_username + ":" + api_password))
    headers = {'Authorization': auth}

    conn.request("POST", url, body=json.dumps(body), headers=headers)

    r = conn.getresponse()
    if r.status != 200:
        raise Exception(r.reason)

