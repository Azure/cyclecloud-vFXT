import urllib
import httplib
import string
import base64
import json
import util
import urlparse
import pdb

import tempfile
import os
import jetpack.config
import jetpack.cli



def cluster(name=None,key=None, config=None):
    """ Set several arrays in bulk """
    #config = util.parse_config(config)
    config = {'cycle_server' : 
            {"webserver" : "http://localhost:8080", 
            "api_username" : "cyclecloud_access",
            "api_password" : "J5Aow5E4gN",
            "cluster_name" : "ogs"
            },
            "identity" : {"cluster_name" : "ogs"}
        }

    webserver = config['cycle_server']['webserver']
    api_username = config['cycle_server']['api_username']
    api_password = config['cycle_server']['api_password']

    cluster_name = config['identity']['cluster_name']
    account_name = 'default'

    conn = None
    u = urlparse.urlparse(webserver)
    if u[0].lower() == "https":
        conn = httplib.HTTPSConnection(u[1])
    else:
        conn = httplib.HTTPConnection(u[1])
    
    url = "/cloud/chefnode/%s/%s" % (account_name,cluster_name)
    print(url)
    auth = 'Basic ' + string.strip(base64.encodestring(api_username + ":" + api_password))
    headers = {'Authorization': auth}

    conn.request("GET", url, headers=headers)

    r = conn.getresponse()
    if r.status != 200:
        raise Exception(r.reason)
    data = json.loads(r.read())
    
    # data['name'] = hostname
    # data['default']  
    # data['default'].['cyclecloud'].['instance']
    names  = []
    values = []
    MSG = ""
    for dat in data:
        f1 = tempfile.NamedTemporaryFile(delete=False)
        json.dump(dat, f1)
        f1.close()
        name = jetpack.config.get('name',configuration_file=f1.name)
        print(name)
        v = jetpack.config.get(key,configuration_file=f1.name)
        if isinstance(v,dict):
            output = jetpack.cli._format_dict(v)
            print(output)
                
    os.remove(f1.name)



