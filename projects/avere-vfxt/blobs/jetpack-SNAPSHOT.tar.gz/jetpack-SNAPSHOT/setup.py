from setuptools import setup
from setuptools import find_packages
from setuptools.command.test import test as TestCommand
import os


class PyTest(TestCommand):
    def finalize_options(self):
        import os
        TestCommand.finalize_options(self)
        xml_out = os.path.join('.', 'build', 'test-results', 'pytest.xml')
        if not os.path.exists(os.path.dirname(xml_out)):
            os.makedirs(os.path.dirname(xml_out))
        self.test_args = ['tests', '--junitxml=%s' % xml_out]
        self.test_suite = True

    def run_tests(self):
        # import here, cause outside the eggs aren't loaded
        import sys
        import pytest
        errno = pytest.main(self.test_args)
        sys.exit(errno)

setup(
    name='jetpack',

    # Note: __JETPACK_VERSION__ is set by the build script for jenkins use
    version=os.environ.get('__JETPACK_VERSION__', 'SNAPSHOT'),

    packages=find_packages(),
    install_requires=['click==4.0', 'anyjson==0.3.3', 'amqp==1.4.6', 'kombu==3.0.24'],

    # Tests require nose, and use the nose.collector
    # Run tests via: python setup.py test
    tests_require=['pytest==2.7.0', 'mock==1.0.1'],
    cmdclass={'test': PyTest},

    url='http://www.cyclecomputing.com',
    maintainer='Cycle Computing',
    maintainer_email='support@cyclecomputing.com',
    license='LICENSE.txt',
    long_description='Jetpack Command Line Interface',
    scripts=['bin/jetpack', 'bin/jetpack-admin'],
    zip_safe=False
)
