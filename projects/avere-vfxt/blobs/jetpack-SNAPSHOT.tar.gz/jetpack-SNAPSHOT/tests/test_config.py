import unittest
import mock
import jetpack.config
from jetpack.config import ConfigError


class TestConfig(unittest.TestCase):
    def setUp(self):
        pass

    def test_config_file(self):
        self.assertEquals("/opt/cycle/jetpack/config/node.json", jetpack.config._config_file())
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            self.assertEquals("C:\\cycle\\jetpack\\config\\node.json", jetpack.config._config_file())

    def test_get_data(self):

        # Test that it all works
        with mock.patch('jetpack.config.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = '{"foo": 1, "bar": 2}'

            actual = jetpack.config._get_data()
            expected = {
                "foo": 1,
                "bar": 2,
            }
            self.assertEquals(actual, expected)

        # Test a file open error
        with mock.patch('jetpack.config.open', mock.mock_open(), create=True) as mock_open:
            mock_open.side_effect = IOError("The isn't found!")
            self.assertRaises(ConfigError, jetpack.config._get_data)
            # TODO: Verify the specific error?

        # Test a json loads error
        with mock.patch('jetpack.config.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = 'THIS IS NOT JSON'

            self.assertRaises(ConfigError, jetpack.config._get_data)
            # TODO: Verify the specific error?

        # Passing in a different config file
        with mock.patch('jetpack.config.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = '{}'
            actual = jetpack.config._get_data('/tmp/test.json')
            mock_open.assert_called_once_with('/tmp/test.json')

    def test_get(self):
        with mock.patch('jetpack.config._get_data') as get_data:
            get_data.return_value = {
                "cycle_server": {
                    "http_port": 80,
                    "https_port": 443
                },
                "knob": True
            }
            self.assertEquals(True, jetpack.config.get('knob'))
            self.assertEquals(80, jetpack.config.get('cycle_server.http_port'))
            self.assertEquals("my-default", jetpack.config.get('cycle_server.foo', 'my-default'))
            self.assertRaises(ConfigError, jetpack.config.get, 'value.does.not.exist')
            # TODO: Verify specific error?

        # Verify using a custom config file
        with mock.patch('jetpack.config._get_data') as get_data:
            get_data.return_value = {'a': 'b'}
            self.assertEquals('b', jetpack.config.get('a', configuration_file='/tmp/test.json'))
            get_data.assert_called_once_with('/tmp/test.json')


    def test_format(self):
        input_dict = {
            "cycle_server": {
                "A": "One",
                "B": 443
            },
            "knob": True
        }

        expected = "\n  cycle_server = <nested>\n  knob         = True"
        self.assertEquals(expected, jetpack.cli._format_dict(input_dict))

    def test_value_none(self):

        # Test that it all works
        with mock.patch('jetpack.config._get_data') as get_data:
            get_data.return_value = {'a': 'b'}

            self.assertEquals(get_data.return_value, jetpack.config.get())

