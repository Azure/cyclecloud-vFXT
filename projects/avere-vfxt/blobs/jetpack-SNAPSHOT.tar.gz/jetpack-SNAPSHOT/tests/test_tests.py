import unittest


class TestTests(unittest.TestCase):
    def test_run(self):
        self.assertTrue(True)