import unittest
from jetpack import amqp_connection
import mock


class TestAmqpConnection(unittest.TestCase):
    def setUp(self):
        pass

    def test_initialize(self):

        # Basic initialization
        conn = amqp_connection.AmqpConnection("my connection", config={})
        self.assertEquals(amqp_connection._default_config, conn.config)
        self.assertEquals("my connection", conn.name)

        # Partial configuration, convert port to int
        conn = amqp_connection.AmqpConnection('my connection', {'port': '1342'})
        self.assertEquals(1342, conn.config['port'])

    def test_open(self):
        conn = amqp_connection.AmqpConnection("my connection", config={})
        with mock.patch('jetpack.amqp_connection.Connection') as mock_connection:
            mock_connection.return_value = mock.Mock()
            mock_connection.return_value.connect.return_value = True
            conn.open()
            mock_connection.assert_called_once_with(
                hostname='localhost',
                port=5672,
                virtual_host="/",
                userid="guest",
                password="guest")
            mock_connection.return_value.connect.assert_called_once()

            # Re-opening will cause an error
            self.assertRaises(Exception, conn.open)

    def test_send(self):
        conn = amqp_connection.AmqpConnection("my connection", config={})
        conn.connection = None
        self.assertRaises(Exception, conn.send, "will generate exception")

        conn.connection = mock.Mock()
        with mock.patch('jetpack.amqp_connection.Exchange') as mock_exchange:
            mock_exchange.return_value = mock.Mock()
            with mock.patch('jetpack.amqp_connection.Producer') as mock_producer:

                # Override all the params
                conn.send("message", exchange="foo", exchange_type="bar", routing_key="baz", headers={"a": 1})

                mock_exchange.assert_called_once_with("foo", type="bar")
                mock_producer.assert_called_once_with(conn.connection)
                mock_producer.return_value.publish.assert_called_once_with("message", exchange=mock_exchange.return_value, routing_key="baz", headers={"a": 1})

                # Use defaults
                mock_exchange.reset_mock()
                mock_producer.reset_mock()
                conn.send('my message')
                mock_exchange.assert_called_once_with('', type='direct')
                mock_producer.assert_called_once_with(conn.connection)
                mock_producer.return_value.publish.assert_called_once_with('my message', exchange=mock_exchange.return_value, routing_key='', headers=None)

    def test_send_json(self):
        with mock.patch('jetpack.amqp_connection.AmqpConnection.send') as mock_send:
            conn = amqp_connection.AmqpConnection("my connection", config={})
            conn.send_json({"foo": "bar"}, exchange='ex1', exchange_type='type1', routing_key="blah", headers={'a': 1})
            mock_send.assert_called_once_with('{"foo": "bar"}', 'ex1', 'type1', "blah", {'a': 1})

    def test_close(self):
        # Close an open connection (mock out the actual connection)
        conn = amqp_connection.AmqpConnection("my connection", config={})
        mock_connection = mock.Mock()
        conn.connection = mock_connection
        conn.close()
        mock_connection.close.assert_called_once()
        self.assertEquals(None, conn.connection)
