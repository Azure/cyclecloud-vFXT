import unittest
import mock
from jetpack import amqp


class TestAmqpLog(unittest.TestCase):
    def setUp(self):
        self.config = {
            'identity': {
                'instance_id': 'i-1234abcd',
                'cluster_name': 'test cluster'
            },
            'amqp': {
                'username': 'guest',
                'password': 'guest',
                'vhost': '/',
                'port': 5672,
                'hostname': 'localhost',
                'exchange': 'cyclecloud.topic',
                'exchange_type': 'topic'

            }
        }

    def test_get_priority(self):
        self.assertEquals('medium', amqp._get_priority('info'))
        self.assertEquals('medium', amqp._get_priority('warn'))
        self.assertEquals('high', amqp._get_priority('error'))
        self.assertRaises(amqp.LogError, amqp._get_priority, "unknown level")

    def test_log(self):
        # No config raises error
        self.assertRaises(amqp.LogError, amqp.log, "message", "info")

        # Invalid level raises error
        self.assertRaises(amqp.LogError, amqp.log, "message", "invalid level", config={})

        # Test message
        with mock.patch('jetpack.amqp.AmqpConnection', create=True) as mock_connection:
            amqp.log("test message", "info", config=self.config)
            mock_connection.assert_called_once_with('log_command', {
                'username': 'guest',
                'password': 'guest',
                'vhost': '/',
                'port': 5672,
                'hostname': 'localhost',
                'routing_key': 'cyclecloud.log',
                'exchange': 'cyclecloud.topic',
                'exchange_type': 'topic'

            })
            expected_message = {
                "message": "test message",
                "cluster_name": "test cluster",
                "instance_id": "i-1234abcd",
                "log_level": "info",
                "log_priority": "medium"
            }
            expected_headers = {
                "cluster_name": "test cluster",
                "instance_id": "i-1234abcd"
            }
            mock_connection.return_value.__enter__.return_value.send_json.assert_called_once_with(expected_message, headers=expected_headers)
