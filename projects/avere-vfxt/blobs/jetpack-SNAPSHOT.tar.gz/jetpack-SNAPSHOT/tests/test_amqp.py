import unittest
import mock
from jetpack import amqp


class TestAmqpSend(unittest.TestCase):
    def setUp(self):
        pass

    def test_send(self):
        # No config generates an error
        self.assertRaises(amqp.SendError, amqp.send, "message")

        # No message or file generates error
        self.assertRaises(amqp.SendError, amqp.send, config={})

        # Both message and file generates error
        self.assertRaises(amqp.SendError, amqp.send, "message", "/tmp/file.json", config={})

        # Invalid config yields an error
        self.assertRaises(amqp.SendError, amqp.send, "message", config={})

        valid_config = {
            'identity': {
                'instance_id': 'i-1234abcd',
                'cluster_name': 'test cluster'
            },
            'amqp': {
                'username': 'guest',
                'password': 'guest',
                'vhost': '/',
                'port': 5672,
                'hostname': 'localhost',
                'exchange': 'cyclecloud.topic',
                'exchange_type': 'topic'
            }
        }

        # Test message
        with mock.patch('jetpack.amqp.AmqpConnection', create=True) as mock_connection:
            amqp.send('test message', config=valid_config)
            mock_connection.assert_called_once_with("send_message_command", {
                'username': 'guest',
                'password': 'guest',
                'vhost': '/',
                'port': 5672,
                'hostname': 'localhost',
                'routing_key': 'cyclecloud.general',
                'exchange': 'cyclecloud.topic',
                'exchange_type': 'topic'

            })
            mock_connection.return_value.__enter__.return_value.send.assert_called_with("test message",
                                    routing_key=None,
                                    headers={
                                        'cluster_name': 'test cluster',
                                        'instance_id': 'i-1234abcd'
                                    })

            mock_connection.reset_mock()
            with mock.patch('jetpack.amqp.open', mock.mock_open(), create=True) as mock_open:
                mock_open.return_value.read.return_value = "this is a test message from file"
                amqp.send(None, "/tmp/file.txt", routing_key="test", config=valid_config)

                mock_connection.assert_called_once_with("send_message_command", {
                    'username': 'guest',
                    'password': 'guest',
                    'vhost': '/',
                    'port': 5672,
                    'hostname': 'localhost',
                    'routing_key': 'cyclecloud.general',
                    'exchange': 'cyclecloud.topic',
                    'exchange_type': 'topic'

                })
                mock_connection.return_value.__enter__.return_value.send.assert_called_once_with("this is a test message from file",
                                                                                    routing_key="test",
                                                                                    headers={
                                                                                        'cluster_name': 'test cluster',
                                                                                        'instance_id': 'i-1234abcd',
                                                                                    })
