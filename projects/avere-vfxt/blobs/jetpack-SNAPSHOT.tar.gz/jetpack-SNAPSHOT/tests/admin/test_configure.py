import unittest
from jetpack.admin import configure
import mock


class TestAdminConfigure(unittest.TestCase):
    def setUp(self):
        pass

    def test_init(self):
        c = configure.JetpackConfigure()
        self.assertEquals("", c.cyclecloud_bootstrap)
        self.assertEquals("", c.cyclecloud_home)

    def test_set_paths(self):

        # Windows + no enviornment variables
        with mock.patch.dict('jetpack.admin.configure.os.environ', {}):
            with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
                c = configure.JetpackConfigure()
                c._set_paths()
                self.assertEquals("C:\\cycle\\jetpack", c.cyclecloud_home)
                self.assertEquals("C:\\cycle\\jetpack/system/bootstrap", c.cyclecloud_bootstrap)

            # Linux + no enviornment variables
            with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
                c = configure.JetpackConfigure()
                c._set_paths()
                self.assertEquals("/opt/cycle/jetpack", c.cyclecloud_home)
                self.assertEquals("/opt/cycle/jetpack/system/bootstrap", c.cyclecloud_bootstrap)

        # Linux with environment variables
        with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
            with mock.patch.dict('jetpack.admin.configure.os.environ', {'CYCLECLOUD_HOME': '/tmp/cyclecloud',
                                                                        'CYCLECLOUD_BOOTSTRAP': '/tmp/bootstrap'}):
                c = configure.JetpackConfigure()
                c._set_paths()
                self.assertEquals("/tmp/cyclecloud", c.cyclecloud_home)
                self.assertEquals("/tmp/bootstrap", c.cyclecloud_bootstrap)

        # Windows with environment variables
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            with mock.patch.dict('jetpack.admin.configure.os.environ', {'CYCLECLOUD_HOME': 'C:\\cyclecloud',
                                                                        'CYCLECLOUD_BOOTSTRAP': 'C:\\bootstrap'}):
                c = configure.JetpackConfigure()
                c._set_paths()
                self.assertEquals("C:\\cyclecloud", c.cyclecloud_home)
                self.assertEquals("C:\\bootstrap", c.cyclecloud_bootstrap)

    def test_get_instance_id_aws(self):
        c = configure.JetpackConfigure()
        with mock.patch('urllib.urlopen') as mock_open:
            mock_open.return_value.getcode.return_value = 200
            mock_open.return_value.read.return_value = "i-1234abcd"

            self.assertEquals("i-1234abcd", c._get_instance_id_aws())
            mock_open.assert_called_once_with("http://169.254.169.254/latest/meta-data/instance-id/")

            mock_open.reset_mock()
            mock_open.return_value.getcode.return_value = 500
            self.assertEquals("unknown", c._get_instance_id_aws())
            mock_open.assert_called_once_with("http://169.254.169.254/latest/meta-data/instance-id/")

    def test_get_instance_id_azure(self):
        c = configure.JetpackConfigure()
        c.cyclecloud_home = '/tmp'
        user_data = {
            'run_list': '{"cyclecloud": {"instance": {"id": "my-test-id"}}}'
        }
        self.assertEquals("my-test-id", c._get_instance_id_azure(user_data))

        # More complex test for PaaS nodes where we pass in cloud_server and read Azure_RoleInstanceId env var
        with mock.patch.dict('os.environ', {'Azure_RoleInstanceId': 'someRole_IN_1'}):
            user_data = {
                'run_list': '{"cyclecloud": {"instance": {"cloud_service": "myService"}}}'
            }
            self.assertEquals("myService-someRole_IN_1", c._get_instance_id_azure(user_data))

    def test_get_instance_id_gce(self):
        with mock.patch('urllib2.Request') as mock_Request:
            mock_Request.side_effect = Exception("OH NOES")
            c = configure.JetpackConfigure()
            self.assertRaises(configure.JetpackConfigureError, c._get_instance_id_gce)

        with mock.patch('urllib2.Request') as mock_Request:
            with mock.patch('urllib2.urlopen') as mock_urlopen:
                mock_urlopen.return_value.read.side_effect = ["my-project-id", 'my-instance-name']
                c = configure.JetpackConfigure()
                self.assertEquals("my-instance-name@gcp-my-project-id", c._get_instance_id_gce())
                mock_Request.assert_any_call("http://169.254.169.254/computeMetadata/v1/project/project-id", None, {"Metadata-Flavor": "Google"})
                mock_Request.assert_any_call("http://169.254.169.254/computeMetadata/v1/instance/attributes/instance-name", None, {"Metadata-Flavor": "Google"})

    def test_transform_userdata_to_dict(self):
        c = configure.JetpackConfigure()

        # Sample userdata
        user_data = {
            'rabbitmq': {
                'user': 'tester',
                'password': '12345',
                'vhost': '/',
                'hostname': 'localhost',
                'port': '8080'
            },
            'pool': {
                'name': 'my-cluster-name'
            },
            'config': {
                "webServer": "http://127.0.0.1:37140", 
            },
             "run_list": "{\"cyclecloud\": {\"mounts\": {\"ephemeral\": {\"mountpoint\": \"/mnt\", \"order\": 0, \"devices\": [\"/dev/sdb\"]}}, \"node\": {\"template\": \"master\"}, \"config\": {\"username\": \"cyclecloud_access\", \"password\": \"YzkwLAJJNL\"}}, \"run_list\": [\"recipe[cyclecloud]\", \"role[sge_master_role]\", \"recipe[cluster_init]\"]}", 
        }
        with mock.patch.object(configure.JetpackConfigure, '_get_instance_id', return_value="i-abcd"):
            actual = c._transform_userdata_to_dict(user_data)
            expected = {
                'amqp': {
                    'username': 'tester',
                    'password': '12345',
                    'virtual_host': '/',
                    'host': 'localhost',
                    'port': '8080'
                },
                'identity': {
                    'cluster_name': 'my-cluster-name',
                    'instance_id': 'i-abcd'
                },
                'cycle_server': {
                    'webserver': 'http://127.0.0.1:37140',
                    'api_username': 'cyclecloud_access',
                    'api_password': 'YzkwLAJJNL'
                }
            }
            self.assertEquals(actual, expected)

    def test_read_user_data(self):
        c = configure.JetpackConfigure()
        c.cyclecloud_bootstrap = "/tmp"

        # Test with custom path and 'user_data' in file
        with mock.patch('jetpack.admin.configure.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = '{"user_data": {"test": "abcd"}}'
            actual = c._read_user_data('my-custom-user-data.json')
            mock_open.assert_called_once_with('my-custom-user-data.json', 'r')
            self.assertEquals(actual, {'test': 'abcd'})

        # Test default path and no 'user_data' in file
        with mock.patch('jetpack.admin.configure.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = '{"not_user_data": {"test": "abcd"}}'
            actual = c._read_user_data()
            mock_open.assert_called_once_with('/tmp/user-data.json', 'r')
            self.assertEquals(actual, {'not_user_data': {'test': 'abcd'}})

    def test_get_instance_id(self):
        with mock.patch('jetpack.util.get_provider', return_value="azure") as mock_is_azure:
            with mock.patch.object(configure.JetpackConfigure, '_get_instance_id_azure', return_value="my-id") as mock_get_instance_id_azure:
                c = configure.JetpackConfigure()
                self.assertEquals('my-id', c._get_instance_id({"foo": "bar"}))
                mock_is_azure.assert_called_once_with()
                mock_get_instance_id_azure.assert_called_once_with({"foo": "bar"})

        with mock.patch('jetpack.util.get_provider', return_value="aws") as mock_is_azure:
            with mock.patch.object(configure.JetpackConfigure, '_get_instance_id_aws', return_value="i-1234") as mock_get_instance_id_aws:
                c = configure.JetpackConfigure()
                self.assertEquals('i-1234', c._get_instance_id({"foo": "bar"}))
                mock_is_azure.assert_called_once_with()
                mock_get_instance_id_aws.assert_called_once_with()

        with mock.patch('jetpack.util.get_provider', return_value="gce") as mock_provider:
            with mock.patch.object(configure.JetpackConfigure, "_get_instance_id_gce", return_value="my-gce-id") as mock_get_instance_id_gce:
                c = configure.JetpackConfigure()
                self.assertEquals("my-gce-id", c._get_instance_id())
                mock_provider.assert_called_once_with()
                mock_get_instance_id_gce.assert_called_once_with()

    def test_run(self):
        with mock.patch.object(configure.JetpackConfigure, '_set_paths', return_value=None) as mock_set_paths:
            with mock.patch.object(configure.JetpackConfigure, '_read_user_data') as mock_read_user_data:
                mock_read_user_data.return_value = {'test': 'ing'}
                with mock.patch.object(configure.JetpackConfigure, '_transform_userdata_to_dict') as mock_transform_userdata_to_dict:
                    mock_transform_userdata_to_dict.return_value = {'foo': 'bar'}
                    with mock.patch('jetpack.util.write_config') as mock_write_config:
                        c = configure.JetpackConfigure()
                        c.run('/tmp/user-data.json', '/tmp/jetpack.ini')
                        mock_set_paths.assert_called_once()
                        mock_read_user_data.assert_called_once_with('/tmp/user-data.json')
                        mock_transform_userdata_to_dict.assert_called_once_with({'test': 'ing'})
                        mock_write_config.assert_called_once_with({'foo': 'bar'}, '/tmp/jetpack.ini')

    def test_execute(self):
        with mock.patch('jetpack.admin.configure.JetpackConfigure') as MockJetpackConfigure:
            configure.execute(user_data_path='/tmp/user-data.json', jetpack_config='/tmp/jetpack.ini')
            MockJetpackConfigure.return_value.run.assert_called_once_with(user_data_path='/tmp/user-data.json', jetpack_config='/tmp/jetpack.ini')
