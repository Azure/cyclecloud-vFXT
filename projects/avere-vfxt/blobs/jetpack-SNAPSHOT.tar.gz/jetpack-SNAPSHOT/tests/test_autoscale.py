import unittest
import mock
from jetpack import autoscale


class TestAutoscale(unittest.TestCase):
    def setUp(self):
        pass
    
    def test_update(self):
        with mock.patch('jetpack.util.parse_config') as mock_parse_config:
            mock_parse_config.return_value = {
                'cycle_server': {
                    'webserver': 'http://127.0.0.1:8080',
                    'api_username': 'test',
                    'api_password': 'password'
                },
                'identity': {
                    'cluster_name': 'TestCluster'
                }
            }
            with mock.patch('httplib.HTTPConnection') as mockHTTPConnection:
                mockHTTPConnection.return_value.getresponse.return_value.status = 200
                
                autoscale.update([{'Name': 'foo', 'Targetcount': 1}], request_set='test', expiration_interval=7, config="/path/to/config.ini")
                
                mock_parse_config.assert_called_once_with('/path/to/config.ini')
                mockHTTPConnection.assert_called_once_with('127.0.0.1:8080')
                mockHTTPConnection.return_value.request.assert_called_once_with("POST", "/cloud/api/autoscale/TestCluster?expiration_interval=7&request_set=test", body='[{"Targetcount": 1, "Name": "foo"}]', headers={'Authorization': 'Basic dGVzdDpwYXNzd29yZA=='})

    def test_set(self):
        with mock.patch('jetpack.autoscale.update') as mock_update:
            autoscale.set(name="custom", corecount=100)
            mock_update.assert_called_once_with([{
                'Name': 'custom',
                'TargetCoreCount': 100
            }])
