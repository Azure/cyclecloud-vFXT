import unittest
import mock
from jetpack import converge


class TestConverge(unittest.TestCase):
    def setUp(self):
        self.linux_bootstrap = "/opt/cycle/jetpack/system/bootstrap"
        self.linux_logs = "/opt/cycle/jetpack/logs"
        self.win_bootstrap = "c:\\cycle\\jetpack\\system\\bootstrap"
        self.win_logs = "c:\\cycle\\jetpack\\logs"

    def test_cache_userdata(self):
        # If the file already exists we can skip it
        with mock.patch('os.path.exists', return_value=True) as mock_exists:
            with mock.patch("os.path.getsize", return_value=10) as mock_size:
                converge._cache_userdata("/tmp")
                mock_exists.assert_called_once_with("/tmp/user-data.json")
                mock_size.assert_called_once_with("/tmp/user-data.json")

        # Now actually do the cache!
        with mock.patch('os.path.exists', return_value=False):
            with mock.patch('jetpack.converge.Userdata') as mock_Userdata:
                with mock.patch('jetpack.converge.open', mock.mock_open(), create=True) as mock_open:
                    mock_Userdata.return_value.to_json.return_value = '{"foo": "bar"}'
                    converge._cache_userdata('/tmp')
                    mock_open.assert_called_once_with("/tmp/user-data.json", "w")
                    handle = mock_open()
                    handle.write.assert_called_once_with('{"foo": "bar"}')

    def test_sync_chef_repos(self):
        with mock.patch('jetpack.converge.subprocess.check_call') as mock_check_call:
            converge._sync_chef_repos(is_linux=True, bootstrap_path="/tmp/bootstrap", log_path="/tmp/logs")
            mock_check_call.assert_called_once_with("/tmp/bootstrap/sync_chef_repos.py >> /tmp/logs/sync_chef_repos.log 2>&1", shell=True)

            mock_check_call.reset_mock()
            converge._sync_chef_repos(is_linux=False, bootstrap_path="C:\\temp\\bootstrap", log_path="C:\\temp\\logs")
            mock_check_call.assert_called_once_with("python C:\\temp\\bootstrap\\sync_chef_repos.py >> C:\\temp\\logs\\sync_chef_repos.log 2>&1", shell=True)

            mock_check_call.side_effect = Exception("Failed call")
            self.assertRaises(converge.ConvergeError, converge._sync_chef_repos, is_linux=True, bootstrap_path="", log_path="")

    def test_generate_chef_config(self):
        with mock.patch('jetpack.converge.subprocess.check_call') as mock_check_call:
            converge._generate_chef_config(is_linux=True, solo=True, bootstrap_path="/tmp/bootstrap", log_path="/tmp/logs")
            mock_check_call.assert_called_once_with("/tmp/bootstrap/generate_chef_config.rb --solo >> /tmp/logs/generate_chef_config.log 2>&1", shell=True)

            mock_check_call.reset_mock()
            converge._generate_chef_config(is_linux=False, solo=False, bootstrap_path="C:\\temp\\bootstrap", log_path="C:\\temp\\logs")
            mock_check_call.assert_called_once_with("ruby C:\\temp\\bootstrap\\generate_chef_config.rb  >> C:\\temp\\logs\\generate_chef_config.log 2>&1", shell=True)

            mock_check_call.side_effect = Exception("Failed call")
            self.assertRaises(converge.ConvergeError, converge._generate_chef_config, is_linux=True, solo=True, bootstrap_path="", log_path="")

    def test_run_chef_solo(self):
        with mock.patch('jetpack.converge.subprocess.check_call') as mock_check_call:
            converge._run_chef_solo(is_linux=True, log_path="/tmp/logs", flags="")
            mock_check_call.assert_called_once_with("chef-solo -c /opt/cycle/jetpack/system/chef/solo.rb -L /tmp/logs/chef-client.log ", shell=True)

            mock_check_call.reset_mock()
            converge._run_chef_solo(is_linux=False, log_path="C:\\temp\\logs", flags="--test")
            mock_check_call.assert_called_once_with("chef-solo.bat -c C:\\cycle\\jetpack\\system\\chef\\solo.rb -L C:\\temp\\logs\\chef-client.log --test", shell=True)

            mock_check_call.side_effect = Exception("Failed call")
            self.assertRaises(converge.ConvergeError, converge._run_chef_solo, is_linux=True, log_path="", flags="")

    def test_run_chef_client(self):
        with mock.patch('jetpack.converge.subprocess.check_call') as mock_check_call:
            converge._run_chef_client(is_linux=True, log_path="/tmp/logs", flags="")
            mock_check_call.assert_called_once_with("chef-client -c /opt/cycle/jetpack/system/chef/client.rb -L /tmp/logs/chef-client.log ", shell=True)

            mock_check_call.reset_mock()
            converge._run_chef_client(is_linux=False, log_path="C:\\temp\\logs", flags="--test")
            mock_check_call.assert_called_once_with("chef-client.bat -c C:\\cycle\\jetpack\\system\\chef\\client.rb -L C:\\temp\\logs\\chef-client.log --test", shell=True)

            mock_check_call.side_effect = Exception("Failed call")
            self.assertRaises(converge.ConvergeError, converge._run_chef_client, is_linux=True, log_path="", flags="")

    def test_solo_mode(self):
        # CHEF SOLO - Linux
        with mock.patch('jetpack.converge.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = """
            {
                "user_data": {
                    "config": {
                        "chefServer": ""
                    }
                }
            }
            """
            self.assertTrue(converge._solo_mode(self.linux_bootstrap))
            mock_open.assert_called_once_with("%s/user-data.json" % self.linux_bootstrap)

        # CHEF-CLIENT - Windows
        with mock.patch('jetpack.converge.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = """
            {
                "user_data": {
                    "config": {
                        "chefServer": "https://getchef.com"
                    }
                }
            }
            """
            self.assertFalse(converge._solo_mode(self.win_bootstrap))
            mock_open.assert_called_once_with("%s/user-data.json" % self.win_bootstrap)

    def test_linux_converge(self):
        with mock.patch.multiple("jetpack.converge", _run_chef_solo=mock.DEFAULT,
                                                     _run_chef_client=mock.DEFAULT,
                                                     _generate_chef_config=mock.DEFAULT,
                                                     _sync_chef_repos=mock.DEFAULT,
                                                     _cache_userdata=mock.DEFAULT,
                                                     _solo_mode=mock.DEFAULT) as funcs:
            with mock.patch('jetpack.util.already_running', return_value=False):
                with mock.patch('jetpack.admin.configure') as mock_configure:
                    with mock.patch('jetpack.amqp.send', return_value=None):

                        # Test chef-solo
                        funcs['_solo_mode'].return_value = True

                        # Verify that at the end of a converge we blow away the pid file
                        with mock.patch('jetpack.converge.os.path.isfile', return_value=True):
                            with mock.patch('jetpack.converge.os.remove') as mock_remove:
                                converge.execute(debug=False)
                                mock_remove.assert_called_once_with("/opt/cycle/jetpack/system/run/converge.pid")

                        mock_configure.assert_called_once()
                        funcs['_solo_mode'].assert_called_once_with(self.linux_bootstrap)
                        funcs['_cache_userdata'].assert_called_once_with(self.linux_bootstrap)
                        funcs['_sync_chef_repos'].assert_called_once_with(True, self.linux_bootstrap, self.linux_logs)
                        funcs['_generate_chef_config'].assert_called_once_with(True, True, self.linux_bootstrap, self.linux_logs)
                        funcs['_run_chef_solo'].assert_called_once_with(True, self.linux_logs, '')

                        # We don't call chef client in this mode
                        self.assertFalse(funcs['_run_chef_client'].called)

                        # Try again with no-sync enabled
                        funcs['_sync_chef_repos'].reset_mock()
                        converge.execute(no_sync=True)
                        self.assertFalse(funcs['_sync_chef_repos'].called)

        # Test chef-client
        with mock.patch.multiple("jetpack.converge", _run_chef_solo=mock.DEFAULT,
                                                     _run_chef_client=mock.DEFAULT,
                                                     _generate_chef_config=mock.DEFAULT,
                                                     _sync_chef_repos=mock.DEFAULT,
                                                     _cache_userdata=mock.DEFAULT,
                                                     _solo_mode=mock.DEFAULT) as funcs:
            with mock.patch('jetpack.util.already_running', return_value=False):
                with mock.patch('jetpack.admin.configure') as mock_configure:
                    with mock.patch('jetpack.amqp.send', return_value=None):

                        # Test chef-solo
                        funcs['_solo_mode'].return_value = False
                        converge.execute(debug=False)

                        mock_configure.assert_called_once()
                        funcs['_solo_mode'].assert_called_once_with(self.linux_bootstrap)
                        funcs['_cache_userdata'].assert_called_once_with(self.linux_bootstrap)
                        funcs['_generate_chef_config'].assert_called_once_with(True, False, self.linux_bootstrap, self.linux_logs)
                        funcs['_run_chef_client'].assert_called_once_with(True, self.linux_logs, "")

                        # In chef-client mode we don't sync repos or run chef solo
                        self.assertFalse(funcs['_sync_chef_repos'].called)
                        self.assertFalse(funcs['_run_chef_solo'].called)

    def test_windows_converge(self):
        with mock.patch.multiple("jetpack.converge", _run_chef_solo=mock.DEFAULT,
                                                     _run_chef_client=mock.DEFAULT,
                                                     _generate_chef_config=mock.DEFAULT,
                                                     _sync_chef_repos=mock.DEFAULT,
                                                     _cache_userdata=mock.DEFAULT,
                                                     _solo_mode=mock.DEFAULT) as funcs:
            with mock.patch('jetpack.util.already_running', return_value=False):
                with mock.patch('jetpack.admin.configure') as mock_configure:
                    with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
                        with mock.patch('jetpack.amqp.send', return_value=None):
                            # Test chef-solo
                            funcs['_solo_mode'].return_value = True
                            converge.execute(debug=False)

                            mock_configure.assert_called_once()
                            funcs['_solo_mode'].assert_called_once_with(self.win_bootstrap)
                            funcs['_cache_userdata'].assert_called_once_with(self.win_bootstrap)
                            funcs['_sync_chef_repos'].assert_called_once_with(False, self.win_bootstrap, self.win_logs)
                            funcs['_generate_chef_config'].assert_called_once_with(False, True, self.win_bootstrap, self.win_logs)
                            funcs['_run_chef_solo'].assert_called_once_with(False, self.win_logs, '')

                            # We don't call chef client in this mode
                            self.assertFalse(funcs['_run_chef_client'].called)

                # Test chef-client
            with mock.patch.multiple("jetpack.converge", _run_chef_solo=mock.DEFAULT,
                                                         _run_chef_client=mock.DEFAULT,
                                                         _generate_chef_config=mock.DEFAULT,
                                                         _sync_chef_repos=mock.DEFAULT,
                                                         _cache_userdata=mock.DEFAULT,
                                                         _solo_mode=mock.DEFAULT) as funcs:
                with mock.patch('jetpack.util.already_running', return_value=False):
                    with mock.patch('jetpack.admin.configure') as mock_configure:
                        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
                            with mock.patch('jetpack.amqp.send', return_value=None):

                                # Test chef-solo
                                funcs['_solo_mode'].return_value = False
                                converge.execute(debug=False)

                                mock_configure.assert_called_once()
                                funcs['_solo_mode'].assert_called_once_with(self.win_bootstrap)
                                funcs['_cache_userdata'].assert_called_once_with(self.win_bootstrap)
                                funcs['_generate_chef_config'].assert_called_once_with(False, False, self.win_bootstrap, self.win_logs)
                                funcs['_run_chef_client'].assert_called_once_with(False, self.win_logs, "")

                                # In chef-client mode we don't sync repos or run chef solo
                                self.assertFalse(funcs['_sync_chef_repos'].called)
                                self.assertFalse(funcs['_run_chef_solo'].called)

    def test_already_running(self):
        # Raises ConvergeError since it's already runing
        with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
            with mock.patch('jetpack.util.already_running', return_value=True):
                self.assertRaises(converge.ConvergeError, converge.execute)
