import unittest
import mock
from jetpack.converge import userdata
from xml.etree import cElementTree as ET


class TestUserdata(unittest.TestCase):
    def setUp(self):
        with mock.patch('jetpack.util.get_provider', return_value="test-provider"):
            self.ud = userdata.Userdata()

    def test_etree_to_dict(self):
        # Shamefully borrowed test xml from python.org
        test_data = """<?xml version="1.0"?>
<data>
    <country name="Liechtenstein">
        <rank>1</rank>
    </country>
    <country name="Singapore">
        <rank>4</rank>
    </country>
    <country name="Panama">
        <rank>68</rank>
    </country>
</data>"""
        t = ET.fromstring(test_data)
        self.assertEquals({
            "data": {
                "country": [
                    {"name": "Liechtenstein", "rank": '1'},
                    {"name": "Singapore", "rank": '4'},
                    {"name": "Panama", "rank": '68'}
                ]
            }
        }, userdata.etree_to_dict(t))

    def test_unpad(self):
        self.assertEquals("This is a string", userdata.unpad("This is a stringPADDING\010"))

    def test_init(self):
        with mock.patch('jetpack.util.get_provider', return_value="test-provider"):
            ud = userdata.Userdata()
            self.assertEqual("c1fb884484645b549e93ca6bb311d719b3c933d1bea81935079b89d99466f3f0", ud.key)
            self.assertEqual(None, ud.userdata_raw)
            self.assertEqual("test-provider", ud.provider)
            self.assertEqual("", ud.userdata_hash)
            self.assertEqual("", ud.userdata_xml)

    def test_fetch(self):
        # Test AWS
        self.ud.provider = "aws"
        with mock.patch('urllib2.urlopen') as mock_urlopen:
            mock_urlopen.return_value.read.return_value = "AWS data!"
            self.assertEquals("AWS data!", self.ud.fetch())
            mock_urlopen.assert_called_once_with("http://169.254.169.254/latest/user-data")

        # Test Unknown provider
        self.ud.provider = "unknown"
        self.assertRaises(Exception, self.ud.fetch)

        # Test GCE
        self.ud.provider = "gce"
        with mock.patch('urllib2.Request') as mock_Request:
            with mock.patch('urllib2.urlopen') as mock_urlopen:
                mock_urlopen.return_value.read.return_value = "R0NFIERhdGEh"

                self.assertEquals("GCE Data!", self.ud.fetch())

                mock_Request.assert_called_once_with("http://169.254.169.254/computeMetadata/v1/instance/attributes/cyclecloud-config", None, {"Metadata-Flavor": "Google"})
                mock_urlopen.assert_called_once()
                mock_urlopen.return_value.read.assert_called_once_with()

        self.ud.provider = "azure"
        # Azure + Windows w/ customdata.bin
        # Note: Azure custom data is binary encoded
        with mock.patch('jetpack.converge.userdata.os') as mock_os:
            mock_os.name = 'nt'
            with mock.patch('jetpack.converge.userdata.open', mock.mock_open(), create=True) as mock_open:
                mock_open.return_value.read.return_value = "Azure windows data.bin!"
                self.assertEquals("Azure windows data.bin!", self.ud.fetch())
                mock_open.assert_called_once_with("C:\\AzureData\\CustomData.bin", "rb")
                mock_open.return_value.read.assert_called_once()

        # Azure + Linux w/ CustomData
        # Note: Linux CustomData file is base64 encoded
        with mock.patch('jetpack.converge.userdata.os') as mock_os:
            mock_os.name = 'linux'
            with mock.patch('jetpack.converge.userdata.open', mock.mock_open(), create=True) as mock_open:
                with mock.patch('jetpack.converge.userdata.os.path.exists') as mock_exists:
                    mock_exists.return_value = True
                    mock_open.return_value.read.return_value = "QXp1cmUgbGludXggQ3VzdG9tRGF0YQ=="
                    self.assertEquals("Azure linux CustomData", self.ud.fetch())
                    mock_open.assert_called_once_with("/var/lib/waagent/CustomData")
                    mock_open.return_value.read.assert_called_once()
                    mock_exists.assert_called_once_with("/var/lib/waagent/CustomData")

        with mock.patch('jetpack.converge.userdata.os') as mock_os:
            mock_os.name = 'linux'
            with mock.patch('jetpack.converge.userdata.os.path.exists', return_value=False) as mock_exists:
                with mock.patch('jetpack.converge.userdata.parse') as mock_parse:
                    from xml.dom.minidom import parseString
                    tree = parseString("<xml><stuff><CustomData>QXp1cmUgbGludXggWE1M</CustomData><CustomData>The last section says: Azure linux XML in base64</CustomData></stuff></xml>")
                    mock_parse.return_value = tree
                    self.assertEquals("Azure linux XML", self.ud.fetch())
                    mock_parse.assert_called_once_with("/var/lib/waagent/ovf-env.xml")
                    
                    # In newer versions of Azure it appears things are namespaced
                    mock_parse.reset_mock()
                    tree = parseString('<xml xmlns:ns1="http://schemas.microsoft.com/windowsazure"><ns1:stuff><ns1:CustomData>QXp1cmUgbGludXggWE1M</ns1:CustomData><ns1:CustomData>The last section says: Azure linux XML in base64</ns1:CustomData></ns1:stuff></xml>')
                    mock_parse.return_value = tree
                    self.assertEquals("Azure linux XML", self.ud.fetch())
                    mock_parse.assert_called_once_with("/var/lib/waagent/ovf-env.xml")

    def test_gunzip(self):
        data = '\x1f\x8b\x08\x00b\x8dSU\x02\xff\x0b\xc9\xc8,V\x00\xa2D\x85\x92\xd4\xe2\x12\x002\x9fz\xc0\x0e\x00\x00\x00'
        self.assertEquals("This is a test", self.ud.gunzip(data))

    def test_derive_key_and_iv(self):
        key, iv = self.ud._derive_key_and_iv("P@ssw0rd", "S@lT!", key_length=16, iv_length=16)
        self.assertEquals("\xa7\xeb\x01b\xcbKB\x8c\xcb\xe5\xaf\xe2\xa8\xed\xc8\n", key)
        self.assertEquals("\xaf\xa8M\xbc\x1d\xeb\x99\xe9\x96\xf1NM\xf2E\xd3\xc9", iv)

    def test_decrypt(self):
        # This is a unzipped encrypted string generated from CC
        self.assertEquals("This is a test", self.ud.decrypt('U2FsdGVkX18EUadWc1Dn2k64t7buUTBOSMXTX1HUKtU='))

    def test_get(self):
        with mock.patch.object(self.ud, 'fetch', return_value="raw userdata"):
            with mock.patch.object(self.ud, 'gunzip', return_value="unzipped userdata"):
                with mock.patch.object(self.ud, 'decrypt', return_value="decrypted userdata"):
                    self.ud.get()
                    self.assertEquals("raw userdata", self.ud.userdata_raw)
                    self.assertEquals("decrypted userdata", self.ud.userdata_xml)

    def test_to_xml(self):
        with mock.patch.object(self.ud, 'get') as mock_get:
            def side_effect():
                self.ud.userdata_xml = "testing"
            mock_get.return_value = None
            mock_get.side_effect = side_effect
            self.assertEquals("testing", self.ud.to_xml())

            mock_get.reset_mock()
            self.ud.userdata_xml = "already set"
            self.assertEquals("already set", self.ud.to_xml())

    def test_to_json(self):
        self.ud.userdata_hash = {
            'user-data': {
                'sup': 'dawg'
            }
        }
        import json
        expected = json.dumps({
            "user_data": {
                "run_list": "RUNLIST",
                "sup": "dawg"
            }
        }, indent=2)
        with mock.patch.object(self.ud, 'runlist', return_value="RUNLIST"):
            self.assertEquals(expected, self.ud.to_json())

    def test_runlist(self):
        """ Somewhat poorly named method that generates a runlist plus other config data from chef attributes xml """

        # Test empty runlist
        test_data = {
            "user_data": {
            }
        }
        self.ud.userdata_hash = test_data
        self.assertEquals('{"run_list": ["recipe[cyclecloud]", "recipe[cluster_init]"]}', self.ud.runlist())

        # Runlist with cluster_init already in place of a custom recipe, and other attributes
        test_data = {
            'user_data': {
                'chefAttributes': {
                    'image': {
                        'attr': [
                            {"name": "run_list", "value": "[\"recipe[cluster_init]\", \"test\"]"},
                            {"name": "test", "value": '{"some": "data"}'}
                        ]
                    }
                }
            }
        }
        self.ud.userdata_hash = test_data
        self.assertEquals('{"test": {"some": "data"}, "run_list": ["recipe[cyclecloud]", "recipe[cluster_init]", "test"]}', self.ud.runlist())

        # Test failure
        self.ud.userdata_hash = {}
        self.assertRaises(Exception, self.ud.runlist)
