import unittest
import mock
from jetpack import keepalive


class TestKeepalive(unittest.TestCase):
    def setUp(self):
        pass

    def test_process_duration(self):
        self.assertEquals('1h', keepalive._process_duration('1h'))
        self.assertEquals("3d", keepalive._process_duration('3D'))
        self.assertEquals('45m', keepalive._process_duration('45m'))
        self.assertEquals('0', keepalive._process_duration('FoReVeR'))
        self.assertEquals('1h', keepalive._process_duration(None))
        self.assertRaises(keepalive.KeepaliveError, keepalive._process_duration, 'invalid duration')

    def test_keepalive_windows(self):

        # Windows doesn't handle durations, only forever (i.e. '0')
        self.assertRaises(keepalive.KeepaliveError, keepalive._keepalive_windows, '3d')

        with mock.patch('subprocess.Popen') as popen:
            keepalive._keepalive_windows('0')
            popen.assert_called_once_with('schtasks /delete /f /tn HealthCheck', shell=True)

        with mock.patch('subprocess.Popen') as popen:
            popen.side_effect = Exception("Popen be busted yo")
            self.assertRaises(keepalive.KeepaliveError, keepalive._keepalive_windows, '0')

    def test_keepalive_linux(self):
        with mock.patch('jetpack.keepalive.glob', mock.Mock(), create=True) as mock_glob:
            mock_glob.glob.return_value = []
            self.assertRaises(keepalive.KeepaliveError, keepalive._keepalive_linux, '1h')

        with mock.patch('jetpack.keepalive.glob', mock.Mock(), create=True) as mock_glob:
            mock_glob.glob.return_value = ['/tmp/healthcheck/healthcheck']
            with mock.patch('jetpack.keepalive.open', mock.mock_open(), create=True) as mock_open:
                keepalive._keepalive_linux('3d')
                mock_open.assert_called_once_with('/tmp/healthcheck/healthcheck', 'a')
                mock_open.return_value.write.assert_called_once_with('3d')
                mock_open.return_value.close.assert_called_once()

    def test_announce_stay_of_execution(self):
        self.assertEquals("The healthcheck service will be terminated and this instance will stay alive indefinitely",
                          keepalive._announce_stay_of_execution('0'))
        self.assertEquals("Termination of this node will be delayed by 1 hour(s)",
                          keepalive._announce_stay_of_execution('1h'))
        self.assertEquals("Termination of this node will be delayed by 13423 minute(s)",
                          keepalive._announce_stay_of_execution('13423m'))
        self.assertEquals("Termination of this node will be delayed by 5 day(s)",
                          keepalive._announce_stay_of_execution('5d'))

    def test_run(self):
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            with mock.patch('jetpack.keepalive._keepalive_windows') as k:
                msg = keepalive.execute()
                k.assert_called_once_with('1h')
                self.assertEquals('Termination of this node will be delayed by 1 hour(s)', msg)

        with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
            with mock.patch('jetpack.keepalive._keepalive_linux') as k:
                msg = keepalive.execute('forever')
                k.assert_called_once_with('0')
                self.assertEquals('The healthcheck service will be terminated and this instance will stay alive indefinitely', msg)
