import unittest
import mock
from jetpack import admin_cli
from click.testing import CliRunner
import jetpack


class TestJetpackAdmin(unittest.TestCase):
    def setUp(self):
        pass

    def test_configure_command(self):
        with mock.patch('jetpack.admin.configure.execute') as mock_execute:
            runner = CliRunner()
            result = runner.invoke(admin_cli.admin, ['configure'])
            self.assertEquals(0, result.exit_code)
            self.assertEquals("", result.output)
            mock_execute.assert_called_once_with(None, None)

            # TODO: Test params
            mock_execute.reset_mock()
            runner = CliRunner()
            result = runner.invoke(admin_cli.admin, ['configure', '--user-data', '/tmp/user-data.json', '--jetpack-config', '/tmp/jetpack.ini'])
            self.assertEquals(0, result.exit_code)
            self.assertEquals("", result.output)
            mock_execute.assert_called_once_with("/tmp/user-data.json", "/tmp/jetpack.ini")

            # Test unknown error
            mock_execute.reset_mock()
            mock_execute.side_effect = Exception("OMG Who knows!")
            runner = CliRunner()
            result = runner.invoke(admin_cli.admin, ['configure'])
            self.assertEquals(1, result.exit_code)
            self.assertEquals("Error: An unknown error occurred\n", result.output)

            # TODO: Test known error
            mock_execute.reset_mock()
            mock_execute.side_effect = jetpack.admin.configure.JetpackConfigureError("A known error!")
            runner = CliRunner()
            result = runner.invoke(admin_cli.admin, ['configure'])
            self.assertEquals(1, result.exit_code)
            self.assertEquals("Error: A known error!\n", result.output)
