import unittest
from jetpack import util
import mock


class TestUtil(unittest.TestCase):
    def setUp(self):
        pass

    def test_is_azure(self):
        with mock.patch('os.path.exists', return_value=False) as mock_exists:
            self.assertFalse(util._is_azure())
            mock_exists.assert_any_call("C:\\AzureData\\CustomData.bin")
            mock_exists.assert_any_call("/var/lib/waagent/CustomData")
            mock_exists.assert_any_call("/var/lib/waagent/ovf-env.xml")

        with mock.patch('os.path.exists', return_value=True) as mock_exists:
            self.assertTrue(util._is_azure())

    def test_is_aws(self):
        with mock.patch("httplib.HTTPConnection") as mock_HTTPConnection:
            mock_conn = mock.Mock()
            mock_HTTPConnection.return_value = mock_conn
            self.assertFalse(util._is_aws())
            mock_HTTPConnection.assert_called_once_with("169.254.169.254", timeout=2)
            mock_conn.request.assert_called_once_with("GET", "latest/meta-data/")
            mock_conn.getresponse.assert_called_once()
            mock_conn.getresponse.return_value.status.assert_called_once

        with mock.patch("httplib.HTTPConnection") as mock_HTTPConnection:
            mock_conn = mock.Mock()
            mock_conn.getresponse.return_value.status = 200
            mock_HTTPConnection.return_value = mock_conn
            self.assertTrue(util._is_aws())

    def test_is_gce(self):
        with mock.patch('httplib.HTTPConnection') as mock_HTTPConnection:
            mock_HTTPConnection.return_value.getresponse.return_value.getheader.return_value = "GoOgLe"
            self.assertTrue(util._is_gce())
            mock_HTTPConnection.assert_called_once_with("169.254.169.254", timeout=2)
            mock_HTTPConnection.return_value.request.assert_called_once_with("GET", "computeMetadata/v1")
            mock_HTTPConnection.return_value.getresponse.assert_called_once_with()
            mock_HTTPConnection.return_value.getresponse.return_value.getheader.assert_called_once_with("Metadata-Flavor", "")

    def test_get_provider(self):
        with mock.patch('jetpack.util._is_azure', return_value=False):
            with mock.patch('jetpack.util._is_aws', return_value=False):
                self.assertEqual(None, util.get_provider())

        with mock.patch('jetpack.util._is_azure', return_value=True):
            with mock.patch('jetpack.util._is_aws', return_value=False):
                self.assertEqual("azure", util.get_provider())

        with mock.patch('jetpack.util._is_azure', return_value=False):
            with mock.patch('jetpack.util._is_aws', return_value=True):
                self.assertEqual("aws", util.get_provider())

    def test_config_to_dict(self):

        # Build up a config parser and make sure it's converted to a dict
        # correctly.
        import ConfigParser
        parser = ConfigParser.RawConfigParser()
        parser.add_section('states')
        parser.add_section('constants')
        parser.set('states', 'massachusettes', 'boston')
        parser.set('states', 'connecticut', 'hartford')
        parser.set('constants', 'pi', '3.141')
        parser.set('constants', 'e', '2.718')

        result = util._config_to_dict(parser)
        self.assertEquals({
            'states': {
                'massachusettes': 'boston',
                'connecticut': 'hartford'
            },
            "constants": {
                "pi": '3.141',
                "e": '2.718'
            }
        }, result)

    def test_get_config_file(self):
        self.assertEquals("/tmp/test.ini", util._get_config_file("/tmp/test.ini"))
        with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
            self.assertEquals("/opt/cycle/jetpack/config/jetpack.ini", util._get_config_file())
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            self.assertEquals("C:\cycle\jetpack\config\jetpack.ini", util._get_config_file())

    def test_parse_config(self):

        # Verify a missing config yields an empty dict
        with mock.patch('os.path.isfile') as mock_isfile:
            mock_isfile.return_value = False
            self.assertEquals({}, util.parse_config("/tmp/test.ini"))

            mock_isfile.reset_mock()
            mock_isfile.return_value = True
            with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
                with mock.patch('jetpack.util._config_to_dict') as config_to_dict:
                    config_to_dict.return_value = {'a': 1}
                    self.assertEquals({'a': 1}, util.parse_config())
                    mock_isfile.assert_called_once_with('C:\cycle\jetpack\config\jetpack.ini')

            mock_isfile.reset_mock()
            mock_isfile.return_value = True
            with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
                with mock.patch('jetpack.util._config_to_dict') as config_to_dict:
                    config_to_dict.return_value = {'a': 1}
                    self.assertEquals({'a': 1}, util.parse_config())
                    mock_isfile.assert_called_once_with('/opt/cycle/jetpack/config/jetpack.ini')

    def test_write_config(self):
        with mock.patch('jetpack.util._transform_dict_to_ini', return_value="sample ini"):
            with mock.patch('jetpack.util.os.path.exists', return_value=True) as mock_exists:
                with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                    util.write_config({'test': 'dict'}, '/tmp/jetpack.ini')
                    mock_exists.assert_called_once_with('/tmp')
                    mock_open.assert_called_once_with("/tmp/jetpack.ini", "w")
                    mock_open.return_value.write.assert_called_once_with("sample ini")

        with mock.patch('jetpack.util._transform_dict_to_ini', return_value="sample ini"):
            with mock.patch('jetpack.util.os.path.exists', return_value=False) as mock_exists:
                with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                    with mock.patch('jetpack.util.os.makedirs') as mock_makedirs:
                        util.write_config({'test': 'dict'}, '/does/not/exist/jetpack.ini')
                        mock_exists.assert_called_once_with('/does/not/exist')
                        mock_makedirs.assert_called_once_with('/does/not/exist')
                        mock_open.assert_called_once_with("/does/not/exist/jetpack.ini", "w")
                        mock_open.return_value.write.assert_called_once_with("sample ini")

    def test_transform_dict_to_ini(self):
        ini = util._transform_dict_to_ini({
            'cyclecloud': {
                'username': 'my-user',
                'password': 'homer simpson'
            },
            'amqp': {
                'port': 8080,
                'hostname': 'localhost'
            }
        })

        expected_ini = """[cyclecloud]
username=my-user
password=homer simpson

[amqp]
hostname=localhost
port=8080"""
        self.assertEquals(ini, expected_ini)

    def test_pid_running(self):
        # Linux
        with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
            with mock.patch('jetpack.util.os.kill') as mock_kill:
                # Test running
                self.assertTrue(util.pid_running(1337))
                mock_kill.assert_called_once_with(1337, 0)

                mock_kill.reset_mock()
                mock_kill.side_effect = OSError("PID doesn't exist!")
                self.assertFalse(util.pid_running(1337))
                mock_kill.assert_called_once_with(1337, 0)

        # windows
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            with mock.patch('jetpack.util.ctypes') as mock_ctypes:
                kernel32 = mock.Mock()
                mock_ctypes.windll.kernel32 = kernel32
                kernel32.OpenProcess.return_value = 1  # Running
                self.assertTrue(util.pid_running(12345))
                kernel32.OpenProcess.called_once_with(0x100000, 0, 12345)
                kernel32.CloseHandle.called_once_with(1)

                kernel32.reset_mock()
                mock_ctypes.reset_mock()
                mock_ctypes.windll.kernel32 = kernel32
                kernel32.OpenProcess.return_value = 0  # Not Running
                kernel32.OpenProcess.called_once_with(0x100000, 0, 12345)
                self.assertFalse(util.pid_running(12345))
                
    def test_stale_file(self):
        DECEMBER_24_2015 = 1450933200
        DECEMBER_25_2015 = 1451019600
        DAY_IN_SECS = 86400
    
        with mock.patch('jetpack.util.os.path.isfile', return_value=True) as mock_isfile:
            with mock.patch('platform.system', mock.MagicMock(return_value="Linux")) as mock_system:
                with mock.patch('jetpack.util.os.path.getmtime', return_value=DECEMBER_24_2015) as mock_getmtime:
                    with mock.patch('jetpack.util.time.time', return_value=DECEMBER_25_2015) as mock_time:
                        with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                            # 1. Linux + not stale
                            # file mtime = DECEMBER_24_2015
                            # current date = DECEMBER_25_2015
                            # uptime = 2 days (boot december 23)
                            # Thus - the file is newer than the last boot so it's not sale
                            mock_open.return_value.readline.return_value = "%s" % DAY_IN_SECS * 2  # up for 2 days
                            self.assertFalse(util.stale_file('/path/to/test.pid'))                            
                            mock_open.assert_any_call("/proc/uptime", 'r')
                                
                            # 2. Linux + stale
                            # filemtime = DECEMBER 24
                            # current date december 25
                            # uptime = half a day 
                            mock_open.return_value.readline.return_value = "%s" % (DAY_IN_SECS / 2)
                            self.assertTrue(util.stale_file("/path/to/test.pid"))
                            
                            # Windows tests are the same as linux except using different process to get the uptime
                            mock_system.return_value = "Windows"
                            with mock.patch('jetpack.util.ctypes') as mock_ctypes:                            
                                kernel32 = mock.Mock()
                                mock_ctypes.windll.kernel32 = kernel32

                                # Windows + no stale
                                # Note: Windows GetTickCount64 is in milliseconds
                                kernel32.GetTickCount64.return_value = float(DAY_IN_SECS * 2 * 1000) 
                                self.assertFalse(util.stale_file("/path/to/test.pid"))
                            
                                # 4. Windows + stale
                                kernel32.GetTickCount64.return_value = float(DAY_IN_SECS / 2 * 1000)
                                self.assertTrue(util.stale_file("/path/to/test.pid"))

    def test_already_running(self):

        # 1: Pid file doesn't exist at all
        with mock.patch('jetpack.util.os.path.isfile', return_value=False) as mock_isfile:
            with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                with mock.patch('jetpack.util.os.getpid', return_value=1337) as mock_getpid:
                    self.assertFalse(util.already_running("/path/to/test.pid"))
                    mock_isfile.assert_called_once_with("/path/to/test.pid")
                    mock_open.assert_called_once_with('/path/to/test.pid', 'w')
                    mock_getpid.assert_called_once()
                    mock_open.return_value.write.assert_called_once_with("1337")

        # 2: Pid file exists and isn't running
        with mock.patch('jetpack.util.os.path.isfile', return_value=True) as mock_isfile:
            with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                with mock.patch('jetpack.util.os.getpid', return_value=1337) as mock_getpid:
                    with mock.patch('jetpack.util.pid_running', return_value=False) as mock_pid_running:
                        with mock.patch('jetpack.util.stale_file', return_value=False) as mock_stale_file:
                            mock_open.return_value.read.return_value = "50"
                            self.assertFalse(util.already_running("/path/to/test.pid"))
                            mock_isfile.assert_called_once_with("/path/to/test.pid")
                            mock_open.assert_any_call("/path/to/test.pid")
                            mock_open.return_value.read.assert_called_once()
                            mock_pid_running.assert_called_once_with(50)
                            mock_open.assert_any_call("/path/to/test.pid", "w")
                            mock_getpid.assert_called_once()
                            mock_open.return_value.write.assert_called_once_with("1337")
                            mock_stale_file.assert_called_once_with("/path/to/test.pid")

        # 3: Pid file exists and IS running
        with mock.patch('jetpack.util.os.path.isfile', return_value=True) as mock_isfile:
            with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                with mock.patch('jetpack.util.pid_running', return_value=True) as mock_pid_running:
                    with mock.patch('jetpack.util.stale_file', return_value=False) as mock_stale_file:
                        mock_open.return_value.read.return_value = "50"
                        self.assertTrue(util.already_running("/path/to/test.pid"))
                        mock_isfile.assert_called_once_with("/path/to/test.pid")
                        mock_open.assert_called_once_with("/path/to/test.pid")
                        mock_open.return_value.read.assert_called_once()
                        mock_pid_running.assert_called_once_with(50)
                        mock_stale_file.assert_called_once_with("/path/to/test.pid")
                        
        # 4. Pid file exists and is running but is stale
        with mock.patch('jetpack.util.os.path.isfile', return_value=True) as mock_isfile:
            with mock.patch('jetpack.util.pid_running', return_value=True) as mock_pid_running:
                with mock.patch('jetpack.util.stale_file', return_value=True) as mock_stale_file:
                    with mock.patch('jetpack.util.open', mock.mock_open(), create=True) as mock_open:
                        self.assertFalse(util.already_running("/path/to/test.pid"))
