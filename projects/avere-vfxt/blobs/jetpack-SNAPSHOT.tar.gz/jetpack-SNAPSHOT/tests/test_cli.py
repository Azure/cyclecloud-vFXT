import unittest
import mock
import jetpack
from jetpack import cli
from click.testing import CliRunner
from jetpack.converge import ConvergeError
import logging
import click
import json


class TestJetpack(unittest.TestCase):
    def setUp(self):
        
        # Mock out logging setup and disable logging for unittests
        jetpack.cli._setup_logging = mock.Mock()
        logging.disable("CRITICAL")
        
    def test_cyclecloud_home(self):
        self.assertEquals("/opt/cycle/jetpack", cli._cyclecloud_home())
        
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            self.assertEquals("C:\\cycle\\jetpack", cli._cyclecloud_home())
            
    def test_handle_exception(self):
        with mock.patch('jetpack.cli.logging') as mock_logging:
            self.assertRaises(click.ClickException, cli._handle_exception)
            mock_logging.getLogger.assert_called_once_with()
            mock_logging.getLogger.return_value.error.assert_called_once()        

    def test_jetpack_command(self):
        # Mock out get for funsies, we want to test the config parsing
        with mock.patch('jetpack.util.parse_config') as parse_config:
            parse_config.return_value = {}
            with mock.patch('jetpack.converge.execute'):  # Mocking execute for fun, not actually testing it
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['converge'])
                self.assertEquals(0, result.exit_code)
                parse_config.assert_called_once_with(None)

                parse_config.reset_mock()
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['-c', '/tmp/test.json', 'converge'])
                self.assertEquals(0, result.exit_code)
                parse_config.assert_called_once_with('/tmp/test.json')

    def test_converge_command(self):
        with mock.patch('jetpack.converge.execute') as execute:
            execute.return_value = None
            runner = CliRunner()
            result = runner.invoke(cli.converge_command)
            self.assertEquals(0, result.exit_code)
            self.assertEquals("Node converged successfully\n", result.output)
            execute.assert_called_once()

        # Known errors shoudl report their message
        with mock.patch('jetpack.converge.execute') as execute:
            execute.side_effect = ConvergeError("Oh noes!")
            runner = CliRunner()
            result = runner.invoke(cli.converge_command)
            self.assertEquals(1, result.exit_code)
            self.assertEquals("Error: Oh noes!\n", result.output)

        with mock.patch('jetpack.converge.execute') as execute:
            execute.side_effect = Exception("Unknown error!")
            runner = CliRunner()
            result = runner.invoke(cli.converge_command)
            self.assertEquals(1, result.exit_code)
            self.assertEquals("Error: An unknown error occurred, please see jetpack.log for details.\n", result.output)

        with mock.patch('jetpack.converge.execute') as execute:
            execute.return_value = None
            runner = CliRunner()
            result = runner.invoke(cli.jetpack, ['converge', '--debug'])
            execute.assert_called_once_with(debug=True, no_sync=False)

        with mock.patch('jetpack.converge.execute') as execute:
            execute.return_value = None
            runner = CliRunner()
            result = runner.invoke(cli.jetpack, ['converge', '--no-sync'])
            execute.assert_called_once_with(debug=False, no_sync=True)

    def test_config_command(self):
        with mock.patch('jetpack.config.get') as get:
            get.return_value = "value"
            runner = CliRunner()
            result = runner.invoke(cli.config_command, ['prop'])

            self.assertEquals(0, result.exit_code)
            self.assertEquals("value\n", result.output)

    def test_config_command_json(self):
        with mock.patch('jetpack.config.get') as get:
            get.return_value = {"key2" : ["one","two"] }
            runner = CliRunner()
            result = runner.invoke(cli.config_command, ['key2','--json'])
            _r = json.loads(result.output)
            
            self.assertEquals(_r, get.return_value)
            self.assertEquals(0, result.exit_code)

    def test_autoscale_command(self):
        with mock.patch('jetpack.autoscale.set') as mock_set:
            runner = CliRunner()
            result = runner.invoke(cli.autoscale_command, ['--name', 'execute', '--corecount', 100])
            self.assertEquals(0, result.exit_code)
            mock_set.assert_called_once_with("execute", 100) 


    def test_keepalive_command(self):
        with mock.patch('jetpack.keepalive.execute') as run:
            run.return_value = "Whatever keepalive returned!"
            runner = CliRunner()
            result = runner.invoke(cli.keepalive_command)
            self.assertEquals(0, result.exit_code)
            self.assertEquals("Whatever keepalive returned!\n", result.output)
            run.assert_called_once()

        # Verify that duration is passed in appropriately
        with mock.patch('jetpack.keepalive.execute') as run:
            run.return_value = "yay, a duration was passed in"
            runner = CliRunner()
            result = runner.invoke(cli.keepalive_command, ['3h'])
            self.assertEquals(0, result.exit_code)
            self.assertEquals('yay, a duration was passed in\n', result.output)
            run.assert_called_once_with('3h')

        with mock.patch('jetpack.keepalive.execute') as run:
            run.side_effect = jetpack.keepalive.KeepaliveError("Bad Juju")
            runner = CliRunner()
            result = runner.invoke(cli.keepalive_command)
            self.assertEquals(1, result.exit_code)
            self.assertEquals("Error: Bad Juju\n", result.output)

        with mock.patch('jetpack.keepalive.execute') as run:
            run.side_effect = Exception("Something bad happened!")
            runner = CliRunner()
            result = runner.invoke(cli.keepalive_command)
            self.assertEquals(1, result.exit_code)
            self.assertEquals("Error: An unknown error occurred, please see jetpack.log for details.\n", result.output)

    def test_log_command(self):
        with mock.patch('jetpack.util.parse_config') as parse_config:
            parse_config.return_value = {
                'identity': {
                    'instance_id': 'i-1234abcd',
                    'cluster_name': 'test cluster'
                },
                'amqp': {
                    'username': 'my-user',
                    'password': 'my-pass',
                    'vhost': '/',
                    'port': 1234,
                    'hostname': '3.4.5.6'
                }
            }

            with mock.patch("jetpack.amqp.log") as log:
                log.side_effect = Exception("Oh noes!")
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['log', 'this is a test'])
                self.assertEquals(1, result.exit_code)
                self.assertEquals("Error: An unknown error occurred, please see jetpack.log for details.\n", result.output)

                log.reset_mock()
                log.side_effect = jetpack.amqp.LogError("Error doing log")
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['log', 'this is a test'])
                self.assertEquals(1, result.exit_code)
                self.assertEquals("Error: Error doing log\n", result.output)

                # Test legit command!
                log.reset_mock()
                log.side_effect = None
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['log', 'this is a test'])
                log.assert_called_once_with('this is a test', 'info', None, config=parse_config.return_value)
                self.assertEquals("", result.output)
                self.assertEquals(0, result.exit_code)

                # Test some parsing
                log.reset_mock()
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['log', 'this is a test', '-l', 'error', '-p', 'medium'])
                log.assert_called_one_with('this is a test', 'error', 'medium', config=parse_config.return_value)
                self.assertEquals(0, result.exit_code)
                self.assertEquals("", result.output)

    def test_send_command(self):
        with mock.patch('jetpack.util.parse_config') as parse_config:
            parse_config.return_value = {
                'identity': {
                    'instance_id': 'i-1234abcd',
                    'cluster_name': 'test cluster'
                },
                'amqp': {
                    'username': 'my-user',
                    'password': 'my-pass',
                    'vhost': '/',
                    'port': 1234,
                    'hostname': '3.4.5.6'
                }
            }
            with mock.patch('jetpack.amqp.send') as send:
                send.side_effect = Exception("Oh noes!")
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['send', '-m', 'this is a test'])
                self.assertEquals(1, result.exit_code)
                self.assertEquals("Error: An unknown error occurred, please see jetpack.log for details.\n", result.output)
                send.assert_called_once_with(message='this is a test', file=None, routing_key=None, config=parse_config.return_value)

                send.reset_mock()
                send.side_effect = jetpack.amqp.SendError("Oh noes!")
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['send', '-m', 'this is a test'])
                self.assertEquals(1, result.exit_code)
                self.assertEquals("Error: Oh noes!\n", result.output)
                send.assert_called_once_with(message='this is a test', file=None, routing_key=None, config=parse_config.return_value)

                # test params
                send.reset_mock()
                send.side_effect = None
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['send', '-f', '/tmp/config.json', '--routing-key', 'foo'])
                self.assertEquals(0, result.exit_code)
                self.assertEquals("", result.output)
                send.assert_called_once_with(message=None, file='/tmp/config.json', routing_key='foo', config=parse_config.return_value)

    def test_version_command(self):
        with mock.patch('jetpack.cli.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = '1.2.3-build'
            with mock.patch('jetpack.cli.os.path.exists') as mock_exists:
                mock_exists.return_value = True
                with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
                    runner = CliRunner()
                    result = runner.invoke(cli.jetpack, ['--version'])
                    self.assertEquals(0, result.exit_code)
                    self.assertEquals("1.2.3-build\n", result.output)
                    mock_exists.assert_called_once_with('C:\\cycle\\jetpack/version.txt')
                    mock_open.assert_called_once_with('C:\\cycle\\jetpack/version.txt', 'r')

        with mock.patch('jetpack.cli.open', mock.mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = '1.2.3-build'
            with mock.patch('jetpack.cli.os.path.exists') as mock_exists:
                mock_exists.return_value = True
                with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
                    runner = CliRunner()
                    result = runner.invoke(cli.jetpack, ['-v'])
                    self.assertEquals(0, result.exit_code)
                    self.assertEquals("1.2.3-build\n", result.output)
                    mock_exists.assert_called_once_with('/opt/cycle/jetpack/version.txt')
                    mock_open.assert_called_once_with('/opt/cycle/jetpack/version.txt', 'r')

        # Error cases: file does not exist
        with mock.patch('platform.system', mock.MagicMock(return_value="Linux")):
            with mock.patch('jetpack.cli.os.path.exists') as mock_exists:
                mock_exists.return_value = False
                runner = CliRunner()
                result = runner.invoke(cli.jetpack, ['-v'])
                self.assertEquals(1, result.exit_code)
                self.assertEquals("Error: Unable to read version in /opt/cycle/jetpack/version.txt\n", result.output)

        # Error cases: can't read for some reason
        with mock.patch('platform.system', mock.MagicMock(return_value="Windows")):
            with mock.patch('jetpack.cli.os.path.exists') as mock_exists:
                mock_exists.return_value = True
                with mock.patch('jetpack.cli.open', mock.mock_open(), create=True) as mock_open:
                    mock_open.side_effect = Exception("Error with open")
                    runner = CliRunner()
                    result = runner.invoke(cli.jetpack, ['-v'])
                    self.assertEquals(1, result.exit_code)
                    self.assertEquals("Error: Unable to read version in C:\cycle\jetpack/version.txt\n", result.output)
