Jetpack CLI / API
=================

This module provides both the Jetpack command line interface (CLI) and Python application
programming interface (API). Once installed one can acess the CLI via the 'jetpack' command
or use the API by importing the 'jetpack' module from a Python script

Installation
------------

This module requires Python 2.7 as this is the version that is pre-installed with
the jetpack installer. Other versions of Python may work, but 2.7 is the version
that 'must' work.

Development
-----------

You should create a virtual environment for jetpack installation and development
running python 2.7, you can do this like so (assuming you have virtualenv installed)::

  virtualenv -p python2.7 /path/to/virtualenv

Enter the virtual environment to bein working::

  source /path/to/virtualenv/bin/activate

Install the requirements for Jetpack::

  pip install -r requirements.txt

At this point you should be all set to being development.

Testing
-------

Tests are located in the test directory, running them all via the command::

  python setup.py nosetests

  python setup.py test  # optional different way of running same tests

If you do not have the test dependencies already install, they should be automatically
installed for you as those dependencies are declared in setup.py


Build and Install
-----------------

The standard distribution method for Jetpack is a pythong .tar.gz or .zip file which
can be pip installed by the larger Jetpack installer or manually for upgrade purposes.
Installation is done via the command::


  python setup.py sdist

Installation should be done via the pip or easy_install to automatically handle
dependencies, but directly calling setup.py will also work::

  pip install jetapck.tar.gz

  easy_install jetpack.tar.gz

  python setup.py install


Usage
-----

The official docs should be consulted for usage information, but basic CLI usage
is as follows::

  $ jetpack config cycle_server.http_port
  $ 8080

  $ jetpack log "this is a log message" --level warn

  $ jetpack send -m "this is a generic message" --routing-key "cyclecloud.log"

  $ jetpack converge

  $ jetpack keepalive 3h

Python API usage is as follows::

  import jetpack

  # Get a configuration value
  port = jetpack.config.get('cycle_server.http_port')
  print port   # 8080

  # send a log message
  jetpack.amqp.log("this is a log message", level="warn", config=AMQP_CONFIG)

  # send a generic amqp message
  jetpack.amqp.send("this is a generic message", routing_key="cyclecloud.log", config=AMQP_CONFIG)

  # execute a converge on the node
  jetpack.converge.execute()

  # Set the healthcheck daemon to stay alive for 3 hours
  jetpack.keepalive.execute("3h")
