#!/bin/bash

set -eou pipefail

CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

function check_for_python() {
   set +e
   python_present=$(command -v python)
   set -e
   if [ -z "$python_present" ] ; then
       echo "ERROR: Missing a Python installation, please install Python 2.7 before proceeding"
       exit 1
   fi

   major_version=$(python --version 2>&1 | tr -d 'Python ' | cut -f1 -d\.)
   if [ $major_version -ne 2 ] ; then
       echo "ERROR: CycleCloud is only compatible with Python 2.7"
       echo "Version ${major_version} found"
       exit 1
   fi
}

check_for_python
python ${CURRENT_DIR}/install.py "$@"
