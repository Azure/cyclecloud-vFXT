#!/usr/bin/env python

import argparse
import subprocess
import platform
import os
import sys
import logging

# insert our vendored virtualenv script at the head of sys.path to ensure it is loaded first
vendored_libs = os.path.join(os.path.dirname(__file__), 'support')
sys.path.insert(0, vendored_libs)


def configure_logging(verbose):
    level = logging.WARN
    if verbose:
        level = logging.DEBUG
        
    logging.basicConfig(level=level)


def is_windows():
    return platform.system().lower().startswith("win")


def is_osx():
    return sys.platform == 'darwin'


def is_linux():
    return not(is_windows()) and not(is_osx())


def print_now(msg, err=False):
    if err:
        stream = sys.stderr
    else:
        stream = sys.stdout

    stream.write("%s\n" % msg)
    stream.flush()


def do_error(msg, do_exit=True):
    msg = "ERROR: " + msg
    print_now(msg, err=True)
    if do_exit:
        print_now('Exiting now')
        sys.exit(1)


def install_virtualenv():
    try:
        import virtualenv
        logging.debug('Able to load virtualenv')

        # ensure the vendored virtualenv was loaded and not the system one
        if 'support' not in virtualenv.__file__:
            do_error('Incorrect version of virtualenv loaded %s' % virtualenv.__file__)
            
    except ImportError:
        do_error('Unable to load vendored virtualenv library')


def create_virtualenv(venv_path):
    import virtualenv
    parentdir = os.path.dirname(venv_path)
    if not os.path.exists(parentdir):
        logging.debug('Creating directory %s' % parentdir)
        os.makedirs(parentdir)
        
    virtualenv.create_environment(venv_path)
    logging.debug('Created virtualenv at %s' % venv_path)


def get_venv_bin_path(venv_path):
    import virtualenv
    paths = virtualenv.path_locations(venv_path)

    # the subdirectory w/ executables varies between windows and everything else
    subdirectory = 'bin'
    if is_windows():
        subdirectory = 'Scripts'
        
    binpaths = filter(lambda p: p.endswith(subdirectory), paths)
    if len(binpaths) < 1:
        do_error('Cannot locate bin directory in virtualenv %s' % venv_path)

    return binpaths[0]


def find_packages(package_path):
    files = [os.path.join(package_path, f) for f in os.listdir(package_path)]
    packages = [p for p in files if os.path.isfile(p)]
    logging.debug('Found packages %s' % packages)
    return packages
    

def install_packages(venv_path, package_path):
    binpath = get_venv_bin_path(venv_path)
    pip_path = os.path.join(binpath, 'pip')
    install_cmd = [pip_path, 'install']
    packages = find_packages(package_path)
    install_cmd.extend(packages)
    logging.debug('Executing command %s' % ' '.join(install_cmd))
    p = subprocess.Popen(install_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    if p.returncode != 0:
        do_error('Installation of packages failed with stderr: %s' % stderr)
    else:
        logging.debug('Successfully installed packages %s' % packages)


def make_link(venv_path, executable):
    binpath = get_venv_bin_path(venv_path)
    source = os.path.join(binpath, executable)
    bindir = os.path.expanduser('~/bin')
    if not os.path.exists(bindir):
        os.makedirs(bindir)
        
    target = os.path.join(bindir, executable)

    if os.path.islink(target):
        logging.debug('Found link %s exists, deleting' % target)
        os.remove(target)
    elif os.path.exists(target):
        do_error('Path %s exists and is not a symlink, cannot update' % target)

    logging.debug('Symlinking %s to %s' % (target, source))
    os.symlink(source, target)


def make_links(venv_path):
    if is_windows():
        logging.debug('Skipping creation of symlinks on windows')
        return
    
    make_link(venv_path, 'cyclecloud')
    make_link(venv_path, 'pogo')
    if '~/bin' not in os.environ['PATH']:
        print_now('\'~/bin\' not found in your PATH environment variable. Make sure to update it',
                  err=True)
    print_now('cyclecloud and pogo commands have been installed to ~/bin')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Installs cyclecloud and pogo cli tools')
    parser.add_argument('--virtualenv', help='path to virtualenv',
                        default='~/.cycle/cli')
    parser.add_argument('--bin-dir', default='~/bin',
                        help='path to link executables into - linux and OS X only')
    parser.add_argument('--packages', help='path to installable packages')
    parser.add_argument('--verbose', help='print logging information',
                        action='store_true', default=False)
    args = parser.parse_args()

    venv_path = os.path.expanduser(args.virtualenv)
    bin_dir = args.bin_dir
    package_dir = args.packages or os.path.join(os.getcwd(), 'packages')
    configure_logging(args.verbose)
    
    install_virtualenv()
    create_virtualenv(venv_path)
    
    install_packages(venv_path, package_dir)
    make_links(venv_path)
