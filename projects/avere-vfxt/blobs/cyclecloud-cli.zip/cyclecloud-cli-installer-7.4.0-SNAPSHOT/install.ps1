$ErrorActionPreference = "Stop"

function choco-install-python() {
    if ((Get-Command "choco.exe" -ErrorAction SilentlyContinue) -ne $null){
        Write-Host "Python 2.7 can be installed with chocolatey with the command 'choco install python2'"
    }
}

function fail-if-missing-python() {
    if ((Get-Command "python.exe" -ErrorAction SilentlyContinue) -eq $null){
        Write-Host "Unable to find $cmd in your PATH. Cyclecloud's command-line requires Python 2.7"
        choco-install-python
        exit 1
    }
}

function add-folder-to-path($folder) {
   $OldPath = [System.Environment]::GetEnvironmentVariable("path")
   $NewPath = $OldPath + $folder + ';'
    [System.Environment]::SetEnvironmentVariable("path", $NewPath, 'Machine')
}

function assert-is-python2() {
   # for some reason python throws an exception if this same command is invoked from
   # powershell
   $version = cmd /c 'python --version 2>&1'
   if (!("$version".Replace('Python ', '').StartsWith('2'))) {
       Write-Host "cyclecloud is incompatible with Python 3"
       choco-install-python
       exit 1
   }
}

function add-cli-to-path() {
    # this command copies our cli commands from .cycle\cli\Scripts to .cycle\cli\bin
    # and then adds .cycle\cli\bin to the PATH
    # this is because the Scripts directory has a number of commands such as pip.exe
    # and python.exe that may conflict with the user's existing Python installation
    $scriptsdir = "${env:USERPROFILE}\.cycle\cli\Scripts"
    $bindir = "${env:USERPROFILE}\.cycle\cli\bin"
    if(!(Test-Path -Path "$bindir")) {
        New-Item -ItemType directory -Path "$bindir"  2>&1 > $null
    }

    cp "${scriptsdir}\cyclecloud.exe" "${bindir}\cyclecloud.exe"
    cp "${scriptsdir}\pogo.exe" "${bindir}\pogo.exe"

    if (!("$env:Path".Contains("$bindir"))) {
        add-folder-to-path "$bindir"
        echo "The cyclecloud and pogo commands have been added to your path. Create a new powershell session to use them"
    }
}


fail-if-missing-python
assert-is-python2
python $PSScriptRoot/install.py $args
add-cli-to-path
